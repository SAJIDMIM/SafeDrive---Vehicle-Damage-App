package com.example.ai_vehicle_damage_app

import android.app.DatePickerDialog
import android.app.ProgressDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.text.SimpleDateFormat
import java.util.*

class VehicleDetailsActivity : AppCompatActivity() {

    private lateinit var txtVehicleType: Spinner
    private lateinit var txtBrand: EditText
    private lateinit var txtModel: EditText
    private lateinit var txtYearOfManufacture: EditText
    private lateinit var txtVehicleNo: EditText
    private lateinit var txtRegistrationDate: EditText
    private lateinit var txtFuelType: Spinner
    private lateinit var txtTransmissionType: Spinner
    private lateinit var txtEngineNo: EditText
    private lateinit var txtChassisNo: EditText
    private lateinit var txtVehicleColor: EditText
    private lateinit var btnContinue: Button
    private lateinit var icPhoto1: ImageView
    private lateinit var icPhoto2: ImageView
    private lateinit var icPhoto3: ImageView

    private lateinit var database: FirebaseDatabase
    private lateinit var storageReference: FirebaseStorage
    private var nationalID: String? = null
    private var selectedImageUri1: Uri? = null
    private var selectedImageUri2: Uri? = null
    private var selectedImageUri3: Uri? = null
    private var currentPhotoView: ImageView? = null

    // Image picker launcher
    private val getContent = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            when (currentPhotoView?.id) {
                R.id.ic_photo1 -> {
                    selectedImageUri1 = uri
                    icPhoto1.setImageURI(uri)
                    Toast.makeText(this, "Front image selected", Toast.LENGTH_SHORT).show()
                }
                R.id.ic_photo2 -> {
                    selectedImageUri2 = uri
                    icPhoto2.setImageURI(uri)
                    Toast.makeText(this, "Rear image selected", Toast.LENGTH_SHORT).show()
                }
                R.id.ic_photo3 -> {
                    selectedImageUri3 = uri
                    icPhoto3.setImageURI(uri)
                    Toast.makeText(this, "Registration document selected", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vehicle_details)

        initializeViews()
        setupDatePickers()
        setupImageClickListeners()
        setupFirebase()
        setUpSpinners()

        btnContinue.setOnClickListener { saveVehicleDetails() }
    }

    private fun initializeViews() {
        txtVehicleType = findViewById(R.id.txt_vehicleType)
        txtBrand = findViewById(R.id.txt_brand)
        txtModel = findViewById(R.id.txt_model)
        txtYearOfManufacture = findViewById(R.id.txt_yearOfManufacture)
        txtVehicleNo = findViewById(R.id.txt_VehicleNo)
        txtRegistrationDate = findViewById(R.id.txt_registerDate)
        txtFuelType = findViewById(R.id.txt_fuelType)
        txtTransmissionType = findViewById(R.id.txt_transmissionType)
        txtEngineNo = findViewById(R.id.txt_engineNo)
        txtChassisNo = findViewById(R.id.txt_chassisNo)
        txtVehicleColor = findViewById(R.id.txt_vehicleColor)
        btnContinue = findViewById(R.id.btn_vehicleContinue)
        icPhoto1 = findViewById(R.id.ic_photo1)
        icPhoto2 = findViewById(R.id.ic_photo2)
        icPhoto3 = findViewById(R.id.ic_photo3)
    }

    private fun setupDatePickers() {
        txtYearOfManufacture.isFocusable = false
        txtRegistrationDate.isFocusable = false
        txtYearOfManufacture.setOnClickListener { showDatePicker(txtYearOfManufacture) }
        txtRegistrationDate.setOnClickListener { showDatePicker(txtRegistrationDate) }
    }

    private fun setupImageClickListeners() {
        icPhoto1.setOnClickListener {
            currentPhotoView = icPhoto1
            getContent.launch("image/*")
        }

        icPhoto2.setOnClickListener {
            currentPhotoView = icPhoto2
            getContent.launch("image/*")
        }

        icPhoto3.setOnClickListener {
            currentPhotoView = icPhoto3
            getContent.launch("image/*")
        }
    }

    private fun setupFirebase() {
        nationalID = intent.getStringExtra("nationalID")
        database = FirebaseDatabase.getInstance()
        storageReference = FirebaseStorage.getInstance()
    }

    private fun setUpSpinners() {
        val vehicleTypes = arrayOf("Select Vehicle Type", "Car", "Motorcycle", "Truck", "Bus", "Other")
        val fuelTypes = arrayOf("Select Fuel Type", "Petrol", "Diesel", "Electric", "Hybrid")
        val transmissionTypes = arrayOf("Select Transmission Type", "Automatic", "Manual")

        ArrayAdapter(this, android.R.layout.simple_spinner_item, vehicleTypes).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            txtVehicleType.adapter = adapter
        }

        ArrayAdapter(this, android.R.layout.simple_spinner_item, fuelTypes).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            txtFuelType.adapter = adapter
        }

        ArrayAdapter(this, android.R.layout.simple_spinner_item, transmissionTypes).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            txtTransmissionType.adapter = adapter
        }
    }

    private fun saveVehicleDetails() {
        val vehicleType = txtVehicleType.selectedItem.toString()
        val brand = txtBrand.text.toString().trim()
        val model = txtModel.text.toString().trim()
        val yearOfManufacture = txtYearOfManufacture.text.toString().trim()
        val vehicleNo = txtVehicleNo.text.toString().trim()
        val registrationDate = txtRegistrationDate.text.toString().trim()
        val fuelType = txtFuelType.selectedItem.toString()
        val transmissionType = txtTransmissionType.selectedItem.toString()
        val engineNo = txtEngineNo.text.toString().trim()
        val chassisNo = txtChassisNo.text.toString().trim()
        val vehicleColor = txtVehicleColor.text.toString().trim()

        if (vehicleType == "Select Vehicle Type" || brand.isEmpty() || model.isEmpty() ||
            yearOfManufacture.isEmpty() || vehicleNo.isEmpty() || registrationDate.isEmpty() ||
            fuelType == "Select Fuel Type" || transmissionType == "Select Transmission Type" ||
            engineNo.isEmpty() || chassisNo.isEmpty() || vehicleColor.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        if (selectedImageUri1 == null || selectedImageUri2 == null || selectedImageUri3 == null) {
            Toast.makeText(this, "Please upload all required images", Toast.LENGTH_SHORT).show()
            return
        }

        val progressDialog = ProgressDialog(this).apply {
            setMessage("Uploading vehicle details...")
            setCancelable(false)
            show()
        }

        // Format dates to yyyy-MM-dd
        val formattedRegDate = try {
            SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).parse(registrationDate)?.let {
                SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(it)
            } ?: registrationDate
        } catch (e: Exception) {
            registrationDate
        }

        val formattedYear = try {
            SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).parse(yearOfManufacture)?.let {
                SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(it)
            } ?: yearOfManufacture
        } catch (e: Exception) {
            yearOfManufacture
        }

        // Prepare vehicle details
        val vehicleInfo = hashMapOf(
            "vehicleType" to vehicleType,
            "brand" to brand,
            "model" to model,
            "yearOfManufacture" to formattedYear,
            "registrationDate" to formattedRegDate,
            "fuelType" to fuelType,
            "transmissionType" to transmissionType,
            "engineNo" to engineNo,
            "chassisNo" to chassisNo,
            "vehicleColor" to vehicleColor,
            "vehicleNo" to vehicleNo
        )

        uploadImages(vehicleNo) { imageUrls ->
            // Create Images node
            val images = hashMapOf(
                "frontImageUrl" to imageUrls[0],
                "rearImageUrl" to imageUrls[1],
                "registrationImageUrl" to imageUrls[2]
            )

            // Create complete vehicle data structure
            val vehicleData = hashMapOf(
                "VehicleInfo" to vehicleInfo,
                "Images" to images
            )

            // Get reference to user's VehicleDetails
            val userRef = database.getReference("Users").child(nationalID!!).child("VehicleDetails").child(vehicleNo)

            // Get reference to RegisteredVehicles
            val registeredVehiclesRef = database.getReference("RegisteredVehicles").child(vehicleNo)

            // First save to RegisteredVehicles
            registeredVehiclesRef.setValue(nationalID)
                .addOnSuccessListener {
                    // Then save to user's VehicleDetails node
                    userRef.setValue(vehicleData)
                        .addOnSuccessListener {
                            progressDialog.dismiss()
                            Toast.makeText(this, "Vehicle details saved successfully", Toast.LENGTH_SHORT).show()

                            // Proceed to policy details
                            val intent = Intent(this, PolicyDetailsActivity::class.java).apply {
                                putExtra("vehicleNo", vehicleNo)
                                putExtra("nationalID", nationalID)
                            }
                            startActivity(intent)
                            finish()
                        }
                        .addOnFailureListener { e ->
                            progressDialog.dismiss()
                            Toast.makeText(this, "Failed to save vehicle details: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                }
                .addOnFailureListener { e ->
                    progressDialog.dismiss()
                    Toast.makeText(this, "Failed to register vehicle: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun uploadImages(vehicleNo: String, callback: (List<String>) -> Unit) {
        val imageUrls = mutableListOf("", "", "")
        var uploadCount = 0
        val totalImages = 3

        val progressDialog = ProgressDialog(this).apply {
            setMessage("Uploading images...")
            setCancelable(false)
            show()
        }

        // Upload Front Image
        selectedImageUri1?.let { uri ->
            val imageRef = storageReference.reference.child("vehicle_images/$vehicleNo/front_${System.currentTimeMillis()}")
            imageRef.putFile(uri)
                .addOnSuccessListener {
                    imageRef.downloadUrl.addOnSuccessListener { downloadUri ->
                        imageUrls[0] = downloadUri.toString()
                        uploadCount++
                        if (uploadCount == totalImages) {
                            progressDialog.dismiss()
                            callback(imageUrls)
                        }
                    }
                }
                .addOnFailureListener { e ->
                    progressDialog.dismiss()
                    Toast.makeText(this, "Failed to upload front image: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }

        // Upload Rear Image
        selectedImageUri2?.let { uri ->
            val imageRef = storageReference.reference.child("vehicle_images/$vehicleNo/rear_${System.currentTimeMillis()}")
            imageRef.putFile(uri)
                .addOnSuccessListener {
                    imageRef.downloadUrl.addOnSuccessListener { downloadUri ->
                        imageUrls[1] = downloadUri.toString()
                        uploadCount++
                        if (uploadCount == totalImages) {
                            progressDialog.dismiss()
                            callback(imageUrls)
                        }
                    }
                }
                .addOnFailureListener { e ->
                    progressDialog.dismiss()
                    Toast.makeText(this, "Failed to upload rear image: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }

        // Upload Registration Image
        selectedImageUri3?.let { uri ->
            val imageRef = storageReference.reference.child("vehicle_images/$vehicleNo/registration_${System.currentTimeMillis()}")
            imageRef.putFile(uri)
                .addOnSuccessListener {
                    imageRef.downloadUrl.addOnSuccessListener { downloadUri ->
                        imageUrls[2] = downloadUri.toString()
                        uploadCount++
                        if (uploadCount == totalImages) {
                            progressDialog.dismiss()
                            callback(imageUrls)
                        }
                    }
                }
                .addOnFailureListener { e ->
                    progressDialog.dismiss()
                    Toast.makeText(this, "Failed to upload registration image: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun showDatePicker(editText: EditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            editText.setText("$selectedDay/${selectedMonth + 1}/$selectedYear")
        }, year, month, day)

        datePickerDialog.show()
    }
}