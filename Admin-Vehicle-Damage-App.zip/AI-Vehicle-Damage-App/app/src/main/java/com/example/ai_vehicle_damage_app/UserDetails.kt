package com.example.ai_vehicle_damage_app

data class UserDetails(
    val userName: String = "",
    val dob: String = "",
    val address: String = "",
    val gender: String = "",
    val email: String = "",
    val mobileNo: String = "",
    val nic: String = ""
)
