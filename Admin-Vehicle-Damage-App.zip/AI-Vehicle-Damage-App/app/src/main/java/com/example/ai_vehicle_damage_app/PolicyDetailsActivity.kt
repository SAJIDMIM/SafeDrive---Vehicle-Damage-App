package com.example.ai_vehicle_damage_app
import android.app.DatePickerDialog

import PolicyDetails
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.util.Calendar

class PolicyDetailsActivity : AppCompatActivity() {

    private lateinit var txtPolicyType: Spinner
    private lateinit var txtInsuranceProvider: Spinner
    private lateinit var txtStartDate: EditText
    private lateinit var txtEndDate: EditText
    private lateinit var txtPremiumAmount: EditText
    private lateinit var txtCoverageDetails: EditText
    private lateinit var btnSubmit: Button

    private lateinit var database: DatabaseReference

    private var nationalID: String? = null
    private var vehicleNo: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_policy_details)

        txtPolicyType = findViewById(R.id.txt_policyType)
        txtInsuranceProvider = findViewById(R.id.text_insuranceProvider)
        txtStartDate = findViewById(R.id.txt_startDate)
        txtEndDate = findViewById(R.id.txt_expiryDate)
        txtPremiumAmount = findViewById(R.id.txt_premiumAmount)
        txtCoverageDetails = findViewById(R.id.txt_coverageDetails)
        btnSubmit = findViewById(R.id.btn_policyUpdate)


        txtStartDate.isFocusable = false
        txtEndDate.isFocusable = false

        txtStartDate.setOnClickListener {
            showDatePicker(txtStartDate)
        }

        txtEndDate.setOnClickListener {
            showDatePicker(txtEndDate)
        }


        nationalID = intent.getStringExtra("nationalID")
        vehicleNo = intent.getStringExtra("vehicleNo")

        database = FirebaseDatabase.getInstance().getReference("Users")

        setUpPolicyTypeSpinner()
        setUpInsuranceProviderSpinner()

        btnSubmit.setOnClickListener {
            savePolicyDetails()
        }
    }

    private fun setUpPolicyTypeSpinner() {
        val policyTypes = arrayOf("Comprehensive", "Third Party", "Third Party, Fire and Theft")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, policyTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        txtPolicyType.adapter = adapter
    }

    private fun setUpInsuranceProviderSpinner() {
        val insuranceProviders = arrayOf(
            "Select Insurance Provider",
            "Allianz Insurance",
            "AIA Insurance",
            "Aviva Insurance",
            "Zurich Insurance",
            "AXA Insurance",
            "Prudential Insurance"
        )
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, insuranceProviders)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        txtInsuranceProvider.adapter = adapter
    }

    private fun savePolicyDetails() {
        val policyType = txtPolicyType.selectedItem.toString()
        val insuranceProvider = txtInsuranceProvider.selectedItem.toString()
        val startDate = txtStartDate.text.toString().trim()
        val endDate = txtEndDate.text.toString().trim()
        val premiumAmount = txtPremiumAmount.text.toString().trim()
        val coverageDetails = txtCoverageDetails.text.toString().trim()

        if (policyType == "Select Policy Type" || insuranceProvider == "Select Insurance Provider" ||
            startDate.isEmpty() || endDate.isEmpty() || premiumAmount.isEmpty() || coverageDetails.isEmpty()
        ) {
            Toast.makeText(this, "Please fill all the fields", Toast.LENGTH_SHORT).show()
            return
        }

        val policyDetails = PolicyDetails(
            policyType, insuranceProvider, startDate, endDate, premiumAmount, coverageDetails
        )

        if (nationalID != null && vehicleNo != null) {
            database.child(nationalID!!).child("VehicleDetails").child(vehicleNo!!).child("PolicyDetails")
                .setValue(policyDetails)
                .addOnSuccessListener {
                    Toast.makeText(this, "Policy Details Saved Successfully", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener {
                    Toast.makeText(this@PolicyDetailsActivity, "Failed to save policy details", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(this, "National ID or Vehicle No not found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showDatePicker(editText: EditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            val formattedDate = "${selectedDay.toString().padStart(2, '0')}/${(selectedMonth + 1).toString().padStart(2, '0')}/$selectedYear"
            editText.setText(formattedDate)
        }, year, month, day)

        datePickerDialog.show()
    }
}
