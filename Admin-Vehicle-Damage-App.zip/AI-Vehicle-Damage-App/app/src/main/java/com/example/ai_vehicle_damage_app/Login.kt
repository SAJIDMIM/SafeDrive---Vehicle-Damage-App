package com.example.ai_vehicle_damage_app

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class Login : AppCompatActivity() {

    private lateinit var loginEmail: EditText
    private lateinit var loginPassword: EditText
    private lateinit var loginButton: Button
    private lateinit var signupRedirectText: TextView
    private lateinit var passViewIcon: ImageView

    // Hardcoded admin credentials
    private val adminUsername = "admin@gmail.com"
    private val adminPassword = "admin123"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // View bindings
        loginEmail = findViewById(R.id.txt_email)
        loginPassword = findViewById(R.id.txt_password)
        loginButton = findViewById(R.id.btn_login)
        signupRedirectText = findViewById(R.id.id_signup)
        passViewIcon = findViewById(R.id.passViewIcon)

        // Password show/hide toggle
        passViewIcon.setOnClickListener {
            if (loginPassword.inputType == (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)) {
                loginPassword.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                passViewIcon.setImageResource(R.drawable.passview)
            } else {
                loginPassword.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                passViewIcon.setImageResource(R.drawable.hide)
            }
            loginPassword.setSelection(loginPassword.text.length)
        }

        // Login button click listener (admin only)
        loginButton.setOnClickListener {
            val email = loginEmail.text.toString().trim()
            val password = loginPassword.text.toString().trim()

            if (!isValidEmail(email)) {
                loginEmail.error = "Enter a valid email"
                loginEmail.requestFocus()
                return@setOnClickListener
            }

            if (!isValidPassword(password)) {
                loginPassword.error = "Password must be at least 6 characters"
                loginPassword.requestFocus()
                return@setOnClickListener
            }

            if (email == adminUsername && password == adminPassword) {
                Toast.makeText(this, "Admin Login Successful", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, AdminDashboard::class.java))
                finish()
            } else {
                Toast.makeText(this, "Invalid Admin Credentials", Toast.LENGTH_SHORT).show()
            }
        }

        // Disable signup and forgot password
        signupRedirectText.setOnClickListener {
            Toast.makeText(this, "Signup disabled. Admin login only.", Toast.LENGTH_SHORT).show()
        }

        val forgotPasswordText: TextView = findViewById(R.id.textView2)
        forgotPasswordText.setOnClickListener {
            Toast.makeText(this, "Password recovery disabled. Admin login only.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isValidEmail(email: String): Boolean {
        return email.isNotEmpty() && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun isValidPassword(password: String): Boolean {
        return password.length >= 6
    }
}
