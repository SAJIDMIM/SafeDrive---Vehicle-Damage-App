package com.example.ai_vehicle_damage_app

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*
import java.util.*

class PolicyHolderUpdate : AppCompatActivity() {

    private lateinit var edtUserName: EditText
    private lateinit var edtMobileNo: EditText
    private lateinit var edtEmail: EditText
    private lateinit var spinnerVehicleType: Spinner
    private lateinit var edtVehicleNo: EditText
    private lateinit var spinnerPolicyType: Spinner
    private lateinit var edtStartDate: EditText
    private lateinit var edtExpiryDate: EditText

    private lateinit var database: DatabaseReference
    private lateinit var vehicleTypes: List<String>
    private lateinit var policyTypes: List<String>
    private var currentUserId: String? = null
    private var currentVehicleNo: String? = null
    private var currentUserEmail: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_policy_holder_profile)

        initializeViews()
        setupDatePickers()
        setupVehicleSpinner()
        setupPolicySpinner()
        setupDatabase()
        setupButtons()
        promptVehicleNumber()
    }

    private fun initializeViews() {
        edtUserName = findViewById(R.id.edt_userName)
        edtMobileNo = findViewById(R.id.edt_mobileNo)
        edtEmail = findViewById(R.id.edt_email)
        spinnerVehicleType = findViewById(R.id.spinner_vehicleType)
        edtVehicleNo = findViewById(R.id.edt_vehicleNo)
        spinnerPolicyType = findViewById(R.id.spinner_policyType)
        edtStartDate = findViewById(R.id.edt_startDate)
        edtExpiryDate = findViewById(R.id.edt_expiryDate)

        edtStartDate.isFocusable = false
        edtExpiryDate.isFocusable = false
    }

    private fun setupDatePickers() {
        edtStartDate.setOnClickListener { showDatePicker(edtStartDate) }
        edtExpiryDate.setOnClickListener { showDatePicker(edtExpiryDate) }
    }

    private fun showDatePicker(editText: EditText) {
        val calendar = Calendar.getInstance()
        DatePickerDialog(this,
            { _, year, month, day ->
                editText.setText(String.format("%02d/%02d/%d", day, month + 1, year))
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun setupVehicleSpinner() {
        vehicleTypes = listOf("Car", "Motorcycle", "Truck", "Bus", "Other")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, vehicleTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerVehicleType.adapter = adapter
    }

    private fun setupPolicySpinner() {
        policyTypes = listOf("Comprehensive", "Third Party", "Third Party, Fire and Theft")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, policyTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerPolicyType.adapter = adapter
    }

    private fun setupDatabase() {
        database = FirebaseDatabase.getInstance().reference
    }

    private fun setupButtons() {
        findViewById<Button>(R.id.btn_edit).setOnClickListener { updateDetails() }
        findViewById<Button>(R.id.btn_delete).setOnClickListener { confirmDelete() }
    }

    private fun promptVehicleNumber() {
        val input = EditText(this).apply { hint = "Enter Vehicle Number" }

        AlertDialog.Builder(this)
            .setTitle("Find Record")
            .setView(input)
            .setPositiveButton("Search") { _, _ ->
                val vehicleNo = input.text.toString().trim().uppercase()
                if (vehicleNo.isNotEmpty()) fetchData(vehicleNo)
                else Toast.makeText(this, "Vehicle number required", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun fetchData(vehicleNo: String) {
        database.child("RegisteredVehicles").child(vehicleNo)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val userId = snapshot.getValue(String::class.java)
                        if (userId != null) {
                            currentUserId = userId
                            currentVehicleNo = vehicleNo
                            loadUserAndVehicleData(userId, vehicleNo)
                        }
                    } else {
                        Toast.makeText(this@PolicyHolderUpdate, "Vehicle not found", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@PolicyHolderUpdate, "Error reading data", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun loadUserAndVehicleData(userId: String, vehicleNo: String) {
        database.child("Users").child(userId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        currentUserEmail = snapshot.child("email").getValue(String::class.java)
                        val userDetails = snapshot.child("UserDetails")
                        val vehicleInfo = snapshot.child("VehicleDetails").child(vehicleNo).child("VehicleInfo")
                        val policyDetails = snapshot.child("VehicleDetails").child(vehicleNo).child("PolicyDetails")

                        edtUserName.setText(userDetails.child("userName").value?.toString().orEmpty())
                        edtMobileNo.setText(userDetails.child("mobileNo").value?.toString().orEmpty())
                        edtEmail.setText(userDetails.child("email").value?.toString().orEmpty())

                        val vehicleType = vehicleInfo.child("vehicleType").value?.toString().orEmpty()
                        val index = vehicleTypes.indexOfFirst { it.equals(vehicleType, true) }
                        if (index >= 0) spinnerVehicleType.setSelection(index)

                        val policyType = policyDetails.child("policyType").value?.toString().orEmpty()
                        val policyIndex = policyTypes.indexOfFirst { it.equals(policyType, true) }
                        if (policyIndex >= 0) spinnerPolicyType.setSelection(policyIndex)

                        edtVehicleNo.setText(vehicleNo)
                        edtStartDate.setText(policyDetails.child("startDate").value?.toString().orEmpty())
                        edtExpiryDate.setText(policyDetails.child("endDate").value?.toString().orEmpty())
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@PolicyHolderUpdate, "Error loading user data", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun updateDetails() {
        val userId = currentUserId ?: return
        val vehicleNo = currentVehicleNo ?: return

        val userUpdates = mapOf(
            "UserDetails/userName" to edtUserName.text.toString(),
            "UserDetails/mobileNo" to edtMobileNo.text.toString(),
            "UserDetails/email" to edtEmail.text.toString()
        )

        val vehicleUpdates = mapOf(
            "VehicleInfo/vehicleType" to spinnerVehicleType.selectedItem.toString()
        )

        val policyUpdates = mapOf(
            "policyType" to spinnerPolicyType.selectedItem.toString(),
            "startDate" to edtStartDate.text.toString(),
            "endDate" to edtExpiryDate.text.toString()
        )

        database.child("Users").child(userId).updateChildren(userUpdates).addOnSuccessListener {
            database.child("Users").child(userId).child("VehicleDetails").child(vehicleNo)
                .updateChildren(vehicleUpdates).addOnSuccessListener {
                    database.child("Users").child(userId).child("VehicleDetails").child(vehicleNo)
                        .child("PolicyDetails").updateChildren(policyUpdates).addOnSuccessListener {
                            Toast.makeText(this, "Details updated", Toast.LENGTH_SHORT).show()
                        }
                }
        }
    }

    private fun confirmDelete() {
        val userId = currentUserId
        val vehicleNo = currentVehicleNo

        if (userId == null || vehicleNo == null) {
            Toast.makeText(this, "No vehicle selected", Toast.LENGTH_SHORT).show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("Delete Vehicle")
            .setMessage("Delete all data for this vehicle? If this is the only vehicle, the whole user will be deleted.")
            .setPositiveButton("Delete") { _, _ -> checkAndDeleteUserData(userId, vehicleNo) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun checkAndDeleteUserData(userId: String, vehicleNo: String) {
        database.child("Users").child(userId).child("VehicleDetails")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.childrenCount == 1L) {
                        deleteEntireUser(userId, vehicleNo)
                    } else {
                        deleteVehicleOnly(userId, vehicleNo)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@PolicyHolderUpdate, "Check failed", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun deleteEntireUser(userId: String, vehicleNo: String) {
        val emailKey = currentUserEmail?.replace(".", ",")
        val pathsToDelete = listOf(
            "Users/$userId",
            "RegisteredVehicles/$vehicleNo",
            "AccidentReports/$vehicleNo",
            "AcceptedReports/$vehicleNo",
            "DeclinedReports/$vehicleNo",
            "PendingReports/$vehicleNo",
            "ReportStatus/$vehicleNo",
            "ScheduleDeletions/$vehicleNo"
        ) + if (emailKey != null) listOf("AppUsers/$emailKey") else emptyList()

        for (path in pathsToDelete) {
            database.child(path).removeValue()
        }

        Toast.makeText(this, "User and all data deleted", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun deleteVehicleOnly(userId: String, vehicleNo: String) {
        val pathsToDelete = listOf(
            "Users/$userId/VehicleDetails/$vehicleNo",
            "RegisteredVehicles/$vehicleNo",
            "AccidentReports/$vehicleNo",
            "AcceptedReports/$vehicleNo",
            "DeclinedReports/$vehicleNo",
            "PendingReports/$vehicleNo",
            "ReportStatus/$vehicleNo",
            "ScheduleDeletions/$vehicleNo"
        )

        for (path in pathsToDelete) {
            database.child(path).removeValue()
        }

        Toast.makeText(this, "Vehicle data deleted", Toast.LENGTH_SHORT).show()
        finish()
        }
}