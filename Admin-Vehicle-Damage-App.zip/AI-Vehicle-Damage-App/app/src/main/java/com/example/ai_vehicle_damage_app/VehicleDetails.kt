package com.example.ai_vehicle_damage_app

data class VehicleDetails(
    val vehicleType: String = "",
    val brand: String = "",
    val model: String = "",
    val yearOfManufacture: String = "",
    val vehicleNo: String = "",
    val registrationDate: String = "",
    val fuelType: String = "",
    val transmissionType: String = "",
    val engineNo: String = "",
    val chassisNo: String = "",
    val vehicleColor: String = "",
    val frontImageUrl: String = "",
    val rearImageUrl: String = "",
    val registrationImageUrl: String = ""
)