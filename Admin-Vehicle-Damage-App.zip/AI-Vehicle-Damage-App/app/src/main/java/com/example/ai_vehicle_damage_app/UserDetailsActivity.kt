package com.example.ai_vehicle_damage_app

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import android.app.DatePickerDialog
import java.util.Calendar

class UserDetailsActivity : AppCompatActivity() {

    private lateinit var txtUserName: EditText
    private lateinit var txtDOB: EditText
    private lateinit var txtAddress: EditText
    private lateinit var txtGender: Spinner
    private lateinit var txtEmail: EditText
    private lateinit var txtMobileNo: EditText
    private lateinit var txtNIC: EditText
    private lateinit var btnContinue: Button

    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_details)

        txtUserName = findViewById(R.id.txt_userName)
        txtDOB = findViewById(R.id.txt_DOB)
        txtAddress = findViewById(R.id.txt_address)
        txtGender = findViewById(R.id.txt_gender)
        txtEmail = findViewById(R.id.txt_email)
        txtMobileNo = findViewById(R.id.txt_mobileNo)
        txtNIC = findViewById(R.id.txt_nic)
        btnContinue = findViewById(R.id.btn_UserContinue)

        txtDOB.isFocusable = false


        txtDOB.setOnClickListener {
            showDatePicker(txtDOB)
        }

        database = FirebaseDatabase.getInstance().getReference("Users")

        val genderOptions = arrayOf("Select Gender", "Male", "Female", "Other")
        val genderAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, genderOptions)
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        txtGender.adapter = genderAdapter

        btnContinue.setOnClickListener {
            saveUserDetails()
        }
    }

    private fun saveUserDetails() {
        val userName = txtUserName.text.toString().trim()
        val dob = txtDOB.text.toString().trim()
        val address = txtAddress.text.toString().trim()
        val gender = txtGender.selectedItem.toString()
        val email = txtEmail.text.toString().trim()
        val mobileNo = txtMobileNo.text.toString().trim()
        val nic = txtNIC.text.toString().trim()

        if (userName.isEmpty() || dob.isEmpty() || address.isEmpty() || gender == "Select Gender"
            || email.isEmpty() || mobileNo.isEmpty() || nic.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val user = UserDetails(userName, dob, address, gender, email, mobileNo, nic)

        database.child(nic).child("UserDetails").setValue(user)
            .addOnSuccessListener {
                Toast.makeText(this, "User Details Saved Successfully", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, VehicleDetailsActivity::class.java)
                intent.putExtra("nationalID", nic)
                startActivity(intent)
                finish()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to Save User Details", Toast.LENGTH_SHORT).show()
            }
    }
    private fun showDatePicker(editText: EditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            val formattedDate = "${selectedDay.toString().padStart(2, '0')}/${(selectedMonth + 1).toString().padStart(2, '0')}/$selectedYear"
            editText.setText(formattedDate)
        }, year, month, day)

        datePickerDialog.show()
    }
}
