package com.example.ai_vehicle_damage_app

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import com.bumptech.glide.Glide
import com.google.firebase.database.*

class AccidentReportsActivity : AppCompatActivity() {

    private lateinit var backbtn: ImageView
    private lateinit var txt_vehicleNo: TextView
    private lateinit var txt_damageDate: TextView
    private lateinit var txt_location: TextView
    private lateinit var txt_reason: TextView
    private lateinit var text_estimateCompany: TextView
    private lateinit var txt_estimateCost: TextView
    private lateinit var ic_photo1: ImageView
    private lateinit var ic_photo2: ImageView
    private lateinit var ic_photo3: ImageView
    private lateinit var btn_accept: AppCompatButton
    private lateinit var btn_Pending: AppCompatButton
    private lateinit var btn_decline: AppCompatButton // New decline button
    private lateinit var editTextDescription: EditText
    private lateinit var mainContentLayout: LinearLayout
    private lateinit var imageContainer: LinearLayout
    private lateinit var txt_status: TextView
    private lateinit var reportsContainer: LinearLayout

    private val dbRef = FirebaseDatabase.getInstance().getReference("AccidentReports")
    private val reportStatusRef = FirebaseDatabase.getInstance().getReference("ReportStatus")

    private var currentVehicleNo: String = ""
    private var currentTimestamp: String = ""
    private var imageUrls = arrayOf("", "", "")
    private var isFullScreen = false
    private var currentZoomedImage: ImageView? = null
    private var originalImageParams: ViewGroup.LayoutParams? = null
    private var originalImageParent: ViewGroup? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_accident_reports)
        reportsContainer = findViewById(R.id.reportsContainer)
        loadReports()
    }

    private fun loadReports() {
        dbRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                reportsContainer.removeAllViews()

                if (!snapshot.exists()) {
                    showNoReportsMessage()
                    return
                }

                for (vehicleSnapshot in snapshot.children) {
                    val vehicleNo = vehicleSnapshot.key ?: continue
                    for (reportSnapshot in vehicleSnapshot.children) {
                        val timestamp = reportSnapshot.key ?: continue
                        val date = reportSnapshot.child("date").getValue(String::class.java) ?: "N/A"
                        createReportItem(vehicleNo, timestamp, date)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                showToast("Failed to load reports")
            }
        })
    }

    private fun createReportItem(vehicleNo: String, timestamp: String, date: String) {
        val reportButton = Button(this@AccidentReportsActivity).apply {
            text = "$vehicleNo - $date"
            tag = Pair(vehicleNo, timestamp)
            background = ContextCompat.getDrawable(context, R.drawable.banner_background)
            setTextColor(ContextCompat.getColor(context, android.R.color.white))
            setPadding(16.dpToPx(), 12.dpToPx(), 16.dpToPx(), 12.dpToPx())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 8.dpToPx())
            }
            setOnClickListener {
                val (vNo, tStamp) = it.tag as Pair<String, String>
                loadReportDetails(vNo, tStamp)
            }
        }
        reportsContainer.addView(reportButton)
    }

    private fun showNoReportsMessage() {
        val noReportsText = TextView(this@AccidentReportsActivity).apply {
            text = "No accident reports found"
            setTextAppearance(android.R.style.TextAppearance_Medium)
            setTextColor(ContextCompat.getColor(context, android.R.color.darker_gray))
            gravity = android.view.Gravity.CENTER
            setPadding(0, 32.dpToPx(), 0, 0)
        }
        reportsContainer.addView(noReportsText)
    }

    private fun loadReportDetails(vehicleNo: String, timestamp: String) {
        currentVehicleNo = vehicleNo
        currentTimestamp = timestamp

        dbRef.child(vehicleNo).child(timestamp)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    setContentView(R.layout.activity_view_report)
                    initializeViews()
                    populateReportData(snapshot)
                    loadExistingReportStatus()
                    setupImageClickListeners()
                    setupButtonListeners()
                }

                override fun onCancelled(error: DatabaseError) {
                    showToast("Failed to load report details")
                }
            })
    }

    private fun initializeViews() {
        backbtn = findViewById(R.id.backbtn)
        txt_vehicleNo = findViewById(R.id.txt_vehicleNo)
        txt_damageDate = findViewById(R.id.txt_damageDate)
        txt_location = findViewById(R.id.txt_location)
        txt_reason = findViewById(R.id.txt_reason)
        text_estimateCompany = findViewById(R.id.text_estimateCompany)
        txt_estimateCost = findViewById(R.id.txt_estimateCost)
        ic_photo1 = findViewById(R.id.ic_photo1)
        ic_photo2 = findViewById(R.id.ic_photo2)
        ic_photo3 = findViewById(R.id.ic_photo3)
        btn_accept = findViewById(R.id.btn_accept)
        btn_Pending = findViewById(R.id.btn_Pending)
        btn_decline = findViewById(R.id.btn_decline) // Initialize decline button
        editTextDescription = findViewById(R.id.editTextDescription)
        txt_status = findViewById(R.id.txt_status)

        mainContentLayout = findViewById(R.id.linearLayout2)
        imageContainer = ic_photo1.parent as LinearLayout
    }

    private fun populateReportData(doc: DataSnapshot) {
        txt_vehicleNo.text = doc.child("vehicleNo").getValue(String::class.java) ?: "N/A"
        txt_damageDate.text = doc.child("date").getValue(String::class.java) ?: "N/A"
        txt_location.text = doc.child("location").getValue(String::class.java) ?: "N/A"
        txt_reason.text = doc.child("reasonDamage").getValue(String::class.java) ?: "N/A"
        text_estimateCompany.text = doc.child("estimateCompany").getValue(String::class.java) ?: "N/A"
        txt_estimateCost.text = "Rs. ${doc.child("estimateCost").getValue(String::class.java) ?: "N/A"}"

        imageUrls[0] = doc.child("image1").getValue(String::class.java) ?: ""
        imageUrls[1] = doc.child("image2").getValue(String::class.java) ?: ""
        imageUrls[2] = doc.child("image3").getValue(String::class.java) ?: ""

        loadImageWithGlide(ic_photo1, imageUrls[0])
        loadImageWithGlide(ic_photo2, imageUrls[1])
        loadImageWithGlide(ic_photo3, imageUrls[2])
    }

    private fun loadExistingReportStatus() {
        reportStatusRef.child(currentVehicleNo).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val savedReportId = snapshot.child("reportId").getValue(String::class.java)
                    if (savedReportId == currentTimestamp) {
                        val savedDescription = snapshot.child("description").getValue(String::class.java)
                        val savedStatus = snapshot.child("status").getValue(String::class.java)

                        editTextDescription.setText(savedDescription)
                        txt_status.text = "  $savedStatus"
                    } else {
                        txt_status.text = ""
                    }
                } else {
                    txt_status.text = ""
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun setupImageClickListeners() {
        ic_photo1.setOnClickListener { showFullScreenDialog(imageUrls[0]) }
        ic_photo2.setOnClickListener { showFullScreenDialog(imageUrls[1]) }
        ic_photo3.setOnClickListener { showFullScreenDialog(imageUrls[2]) }
    }

    private fun setupButtonListeners() {
        backbtn.setOnClickListener { returnToReportSelection() }
        btn_accept.setOnClickListener { submitReportStatus("Accepted") }
        btn_Pending.setOnClickListener { submitReportStatus("Pending") }
        btn_decline.setOnClickListener { submitReportStatus("Declined") } // Set up decline button
    }

    private fun submitReportStatus(status: String) {
        val description = editTextDescription.text.toString().trim()
        if (description.isEmpty()) {
            showToast("Please enter a description")
            return
        }

        val reportData = hashMapOf(
            "description" to description,
            "status" to status,
            "timestamp" to System.currentTimeMillis(),
            "vehicleNo" to currentVehicleNo,
            "reportId" to currentTimestamp,
            "actionDate" to System.currentTimeMillis() // Track when action was taken
        )

        reportStatusRef.child(currentVehicleNo).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val previousStatus = snapshot.child("status").getValue(String::class.java)

                reportStatusRef.child(currentVehicleNo).setValue(reportData)
                    .addOnSuccessListener {
                        val newTable = when (status) {
                            "Accepted" -> "AcceptReports"
                            "Pending" -> "PendingReports"
                            "Declined" -> "DeclinedReports" // New table for declined reports
                            else -> null
                        }

                        val oldTable = when (previousStatus) {
                            "Accepted" -> "AcceptReports"
                            "Pending" -> "PendingReports"
                            "Declined" -> "DeclinedReports"
                            else -> null
                        }

                        if (oldTable != null && oldTable != newTable) {
                            FirebaseDatabase.getInstance().getReference(oldTable)
                                .child(currentVehicleNo)
                                .child(currentTimestamp)
                                .removeValue()
                        }

                        if (newTable != null) {
                            FirebaseDatabase.getInstance().getReference(newTable)
                                .child(currentVehicleNo)
                                .child(currentTimestamp)
                                .setValue(reportData)
                                .addOnSuccessListener {
                                    showToast("Report updated in $newTable")

                                    // Schedule deletion for both Accepted and Declined reports
                                    if (status == "Accepted" || status == "Declined") {
                                        scheduleReportDeletion(currentVehicleNo, currentTimestamp)
                                    }

                                    returnToReportSelection()
                                }
                                .addOnFailureListener {
                                    showToast("Failed to write to $newTable: ${it.message}")
                                }
                        }
                    }
                    .addOnFailureListener {
                        showToast("Failed to update ReportStatus: ${it.message}")
                    }
            }

            override fun onCancelled(error: DatabaseError) {
                showToast("Failed to check previous report status: ${error.message}")
            }
        })
    }

    private fun scheduleReportDeletion(vehicleNo: String, timestamp: String) {
        val sevenDaysInMillis = 7 * 24 * 60 * 60 * 1000L
        val deleteTime = System.currentTimeMillis() + sevenDaysInMillis

        val scheduledDeletionsRef = FirebaseDatabase.getInstance()
            .getReference("ScheduledDeletions")
            .child(vehicleNo)
            .child(timestamp)

        scheduledDeletionsRef.setValue(deleteTime)
            .addOnSuccessListener {
                showToast("Report scheduled for deletion in 7 days")
            }
            .addOnFailureListener {
                showToast("Failed to schedule deletion: ${it.message}")
            }
    }

    // [Rest of your existing methods remain unchanged...]
    private fun returnToReportSelection() {
        setContentView(R.layout.activity_accident_reports)
        reportsContainer = findViewById(R.id.reportsContainer)
        loadReports()
    }

    private fun showFullScreenDialog(imageUrl: String) {
        if (imageUrl.isEmpty()) return

        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.setContentView(R.layout.dialog_fullscreen_image)

        val imageView = dialog.findViewById<ImageView>(R.id.fullscreenImageView)
        Glide.with(this)
            .load(imageUrl)
            .placeholder(R.drawable.banner_background)
            .error(R.drawable.banner_background)
            .into(imageView)

        imageView.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun loadImageWithGlide(imageView: ImageView, imageUrl: String) {
        if (imageUrl.isNotEmpty()) {
            Glide.with(this)
                .load(imageUrl)
                .placeholder(R.drawable.banner_background)
                .error(R.drawable.banner_background)
                .into(imageView)
        } else {
            imageView.setImageResource(R.drawable.banner_background)
        }
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun Int.dpToPx(): Int {
        val density = resources.displayMetrics.density
        return (this * density).toInt()
    }
}