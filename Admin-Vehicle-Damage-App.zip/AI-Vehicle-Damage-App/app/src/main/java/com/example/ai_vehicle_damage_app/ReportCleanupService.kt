package com.example.ai_vehicle_damage_app

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.*

class ReportCleanupService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        checkAndDeleteOldReports()
    }

    private fun checkAndDeleteOldReports() {
        val currentTime = System.currentTimeMillis()
        val scheduledDeletionsRef = FirebaseDatabase.getInstance().getReference("ScheduledDeletions")

        scheduledDeletionsRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (vehicleSnapshot in snapshot.children) {
                    val vehicleNo = vehicleSnapshot.key ?: continue
                    for (reportSnapshot in vehicleSnapshot.children) {
                        val timestamp = reportSnapshot.key ?: continue
                        val deleteTime = reportSnapshot.getValue(Long::class.java) ?: continue

                        if (currentTime >= deleteTime) {
                            // Time to delete this report
                            deleteReport(vehicleNo, timestamp)
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    private fun deleteReport(vehicleNo: String, timestamp: String) {
        val dbRef = FirebaseDatabase.getInstance().getReference("AccidentReports")

        // Delete from AccidentReports
        dbRef.child(vehicleNo).child(timestamp).removeValue()
            .addOnSuccessListener {
                // Delete from ScheduledDeletions
                FirebaseDatabase.getInstance().getReference("ScheduledDeletions")
                    .child(vehicleNo)
                    .child(timestamp)
                    .removeValue()

                // Optionally delete from AcceptReports if needed
                FirebaseDatabase.getInstance().getReference("AcceptReports")
                    .child(vehicleNo)
                    .child(timestamp)
                    .removeValue()
            }
            .addOnFailureListener {
                // Handle error
            }
    }

    companion object {
        fun startService(context: android.content.Context) {
            val intent = Intent(context, ReportCleanupService::class.java)
            context.startService(intent)
        }
    }
}