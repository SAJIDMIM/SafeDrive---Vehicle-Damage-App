package com.example.ai_vehicle_damage_app

import android.app.Dialog
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.firebase.database.*

class UserAllDetailsActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var backbtn: ImageView

    // User Info
    private lateinit var tvName: TextView
    private lateinit var tvDob: TextView
    private lateinit var tvAddress: TextView
    private lateinit var tvGender: TextView
    private lateinit var tvEmail: TextView
    private lateinit var tvMobile: TextView
    private lateinit var tvId: TextView

    // Vehicle Info
    private lateinit var tvType: TextView
    private lateinit var tvBrand: TextView
    private lateinit var tvModel: TextView
    private lateinit var tvYear: TextView
    private lateinit var tvVehicleNumber: TextView
    private lateinit var tvRegDate: TextView
    private lateinit var tvFuel: TextView
    private lateinit var tvTransmission: TextView
    private lateinit var tvEngine: TextView
    private lateinit var tvChassisNumber: TextView
    private lateinit var tvColor: TextView

    // Policy Info
    private lateinit var tvPolicyType: TextView
    private lateinit var tvPolicyStart: TextView
    private lateinit var tvPolicyEnd: TextView
    private lateinit var tvProvider: TextView
    private lateinit var tvPremium: TextView
    private lateinit var tvCoverage: TextView

    // Images
    private lateinit var icPhoto1: ImageView
    private lateinit var icPhoto2: ImageView
    private lateinit var icPhoto3: ImageView
    private lateinit var imageContainer: LinearLayout

    private var imageUrls = arrayOf("", "", "")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_user_details)

        initializeViews()
        setupImageClickListeners()

        val nic = intent.getStringExtra("nic") ?: return
        database = FirebaseDatabase.getInstance().getReference("Users").child(nic)

        backbtn.setOnClickListener { finish() }

        database.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val userDetails = snapshot.child("UserDetails")
                displayUserDetails(userDetails)

                val vehicleEntry = snapshot.child("VehicleDetails").children.firstOrNull()
                if (vehicleEntry != null) {
                    val vehicleNo = vehicleEntry.key ?: "-"
                    tvVehicleNumber.text = vehicleNo

                    val vehicleInfo = vehicleEntry.child("VehicleInfo")
                    displayVehicleInfo(vehicleInfo)
                    displayPolicyDetails(vehicleEntry.child("PolicyDetails"))

                    // Load images from the Images node
                    loadVehicleImages(vehicleEntry.child("Images"))
                } else {
                    Toast.makeText(this@UserAllDetailsActivity, "No vehicle info found", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@UserAllDetailsActivity, "Error loading data.", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun initializeViews() {
        backbtn = findViewById(R.id.backbtn)

        // User
        tvName = findViewById(R.id.tvName)
        tvDob = findViewById(R.id.tvDob)
        tvAddress = findViewById(R.id.tvAddress)
        tvGender = findViewById(R.id.tvGender)
        tvEmail = findViewById(R.id.tvEmail)
        tvMobile = findViewById(R.id.tvMobile)
        tvId = findViewById(R.id.tvId)

        // Vehicle
        tvType = findViewById(R.id.tvType)
        tvBrand = findViewById(R.id.tvBrand)
        tvModel = findViewById(R.id.tvModel)
        tvYear = findViewById(R.id.tvYear)
        tvVehicleNumber = findViewById(R.id.tvVehicleNumber)
        tvRegDate = findViewById(R.id.tvRegDate)
        tvFuel = findViewById(R.id.tvFuel)
        tvTransmission = findViewById(R.id.tvTransmission)
        tvEngine = findViewById(R.id.tvEngine)
        tvChassisNumber = findViewById(R.id.tvChassisNumber)
        tvColor = findViewById(R.id.tvColor)

        // Policy
        tvPolicyType = findViewById(R.id.tvPolicyType)
        tvPolicyStart = findViewById(R.id.tvPolicyStart)
        tvPolicyEnd = findViewById(R.id.tvPolicyEnd)
        tvProvider = findViewById(R.id.tvProvider)
        tvPremium = findViewById(R.id.tvPremium)
        tvCoverage = findViewById(R.id.tvCoverage)

        // Images
        icPhoto1 = findViewById(R.id.ic_photo1)
        icPhoto2 = findViewById(R.id.ic_photo2)
        icPhoto3 = findViewById(R.id.ic_photo3)
        imageContainer = icPhoto1.parent as LinearLayout
    }

    private fun setupImageClickListeners() {
        icPhoto1.setOnClickListener { showFullScreenDialog(imageUrls[0]) }
        icPhoto2.setOnClickListener { showFullScreenDialog(imageUrls[1]) }
        icPhoto3.setOnClickListener { showFullScreenDialog(imageUrls[2]) }
    }

    private fun displayUserDetails(user: DataSnapshot) {
        tvName.text = user.child("userName").value?.toString() ?: "-"
        tvDob.text = user.child("dob").value?.toString() ?: "-"
        tvAddress.text = user.child("address").value?.toString() ?: "-"
        tvGender.text = user.child("gender").value?.toString() ?: "-"
        tvEmail.text = user.child("email").value?.toString() ?: "-"
        tvMobile.text = user.child("mobileNo").value?.toString() ?: "-"
        tvId.text = user.child("nic").value?.toString() ?: "-"
    }

    private fun displayVehicleInfo(vehicle: DataSnapshot) {
        tvType.text = vehicle.child("vehicleType").value?.toString() ?: "-"
        tvBrand.text = vehicle.child("brand").value?.toString() ?: "-"
        tvModel.text = vehicle.child("model").value?.toString() ?: "-"
        tvYear.text = vehicle.child("yearOfManufacture").value?.toString() ?: "-"
        tvRegDate.text = vehicle.child("registrationDate").value?.toString() ?: "-"
        tvFuel.text = vehicle.child("fuelType").value?.toString() ?: "-"
        tvTransmission.text = vehicle.child("transmissionType").value?.toString() ?: "-"
        tvEngine.text = vehicle.child("engineNo").value?.toString() ?: "-"
        tvChassisNumber.text = vehicle.child("chassisNo").value?.toString() ?: "-"
        tvColor.text = vehicle.child("vehicleColor").value?.toString() ?: "-"
    }

    private fun displayPolicyDetails(policy: DataSnapshot) {
        tvPolicyType.text = policy.child("policyType").value?.toString() ?: "-"
        tvPolicyStart.text = policy.child("startDate").value?.toString() ?: "-"
        tvPolicyEnd.text = policy.child("endDate").value?.toString() ?: "-"
        tvProvider.text = policy.child("insuranceProvider").value?.toString() ?: "-"
        tvPremium.text = policy.child("premiumAmount").value?.toString() ?: "-"
        tvCoverage.text = policy.child("coverageDetails").value?.toString() ?: "-"
    }

    private fun loadVehicleImages(images: DataSnapshot) {
        imageUrls[0] = images.child("frontImageUrl").value?.toString() ?: ""
        imageUrls[1] = images.child("rearImageUrl").value?.toString() ?: ""
        imageUrls[2] = images.child("registrationImageUrl").value?.toString() ?: ""

        loadImageWithGlide(icPhoto1, imageUrls[0])
        loadImageWithGlide(icPhoto2, imageUrls[1])
        loadImageWithGlide(icPhoto3, imageUrls[2])
    }

    private fun loadImageWithGlide(imageView: ImageView, imageUrl: String) {
        if (imageUrl.isNotEmpty()) {
            Glide.with(this)
                .load(imageUrl)
                .placeholder(R.drawable.banner_background)
                .error(R.drawable.banner_background)
                .into(imageView)
        } else {
            imageView.setImageResource(R.drawable.banner_background)
        }
    }

    private fun showFullScreenDialog(imageUrl: String) {
        if (imageUrl.isEmpty()) return

        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.setContentView(R.layout.dialog_fullscreen_image)

        val imageView = dialog.findViewById<ImageView>(R.id.fullscreenImageView)
        Glide.with(this)
            .load(imageUrl)
            .placeholder(R.drawable.banner_background)
            .error(R.drawable.banner_background)
            .into(imageView)

        imageView.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }
}