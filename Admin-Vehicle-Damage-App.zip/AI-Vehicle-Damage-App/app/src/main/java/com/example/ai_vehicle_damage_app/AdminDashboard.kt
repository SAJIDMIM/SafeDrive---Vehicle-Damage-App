package com.example.ai_vehicle_damage_app

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class AdminDashboard : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var pendingRef: DatabaseReference
    private lateinit var approvedRef: DatabaseReference
    private lateinit var declinedRef: DatabaseReference
    private lateinit var reportsRef: DatabaseReference
    private lateinit var totalUserTextView: TextView
    private lateinit var pendingReportsTextView: TextView
    private lateinit var approvedReportsTextView: TextView
    private lateinit var declinedReportsTextView: TextView
    private lateinit var ReportsTextView: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_dashboard)

        // Initialize Firebase Database references
        database = FirebaseDatabase.getInstance().getReference("AppUsers")
        pendingRef = FirebaseDatabase.getInstance().getReference("PendingReports")
        approvedRef = FirebaseDatabase.getInstance().getReference("AcceptReports")
        declinedRef = FirebaseDatabase.getInstance().getReference("DeclinedReports")
        reportsRef = FirebaseDatabase.getInstance().getReference("AccidentReports")


        // Find TextViews to update
        totalUserTextView = findViewById(R.id.id_totalUser)
        pendingReportsTextView = findViewById(R.id.id_pendingReports)
        approvedReportsTextView = findViewById(R.id.id_approvedReports)
        declinedReportsTextView = findViewById(R.id.id_declineReports)
        ReportsTextView = findViewById(R.id.id_Reports)


        // Fetch data
        fetchTotalUserCount()
        fetchTotalPendingReports()
        fetchTotalApprovedReports()
        fetchTotalDeclinedReports()
        fetchTotalReports()


        // Navigation
        val icAddPolicy: ImageView = findViewById(R.id.ic_addPolicy)
        icAddPolicy.setOnClickListener {
            startActivity(Intent(this, UserDetailsActivity::class.java))
        }

        val icAccidentReports: ImageView = findViewById(R.id.ic_AccidentReports)
        icAccidentReports.setOnClickListener {
            startActivity(Intent(this, AccidentReportsActivity::class.java))
        }

        val icPay: ImageView = findViewById(R.id.ic_pay)
        icPay.setOnClickListener {
            startActivity(Intent(this, UserListActivity::class.java))
        }

        val icUpdateProfile: ImageView = findViewById(R.id.ic_UpdateProfile)
        icUpdateProfile.setOnClickListener {
            startActivity(Intent(this, PolicyHolderUpdate::class.java))
        }
    }

    private fun fetchTotalUserCount() {
        database.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                totalUserTextView.text = snapshot.childrenCount.toString()
            }

            override fun onCancelled(error: DatabaseError) {
                totalUserTextView.text = "Error"
            }
        })
    }

    private fun fetchTotalPendingReports() {
        pendingRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var count = 0
                for (vehicleSnapshot in snapshot.children) {
                    count += vehicleSnapshot.childrenCount.toInt()
                }
                pendingReportsTextView.text = count.toString()
            }

            override fun onCancelled(error: DatabaseError) {
                pendingReportsTextView.text = "Error"
            }
        })
    }

    private fun fetchTotalApprovedReports() {
        approvedRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var count = 0
                for (vehicleSnapshot in snapshot.children) {
                    count += vehicleSnapshot.childrenCount.toInt()
                }
                approvedReportsTextView.text = count.toString()
            }

            override fun onCancelled(error: DatabaseError) {
                approvedReportsTextView.text = "Error"
            }
        })
    }
    private fun fetchTotalReports() {
        pendingRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var count = 0
                for (vehicleSnapshot in snapshot.children) {
                    count += vehicleSnapshot.childrenCount.toInt()
                }
                ReportsTextView.text = count.toString()
            }

            override fun onCancelled(error: DatabaseError) {
                ReportsTextView.text = "Error"
            }
        })
    }

    private fun fetchTotalDeclinedReports() {
        declinedRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var count = 0
                for (vehicleSnapshot in snapshot.children) {
                    count += vehicleSnapshot.childrenCount.toInt()
                }
                declinedReportsTextView.text = count.toString()
            }

            override fun onCancelled(error: DatabaseError) {
                declinedReportsTextView.text = "Error"
            }
        })
    }
}
