data class PolicyDetails(
    val policyType: String = "",
    val insuranceProvider: String = "", // ✅ Added field
    val startDate: String = "",
    val endDate: String = "",
    val premiumAmount: String = "",
    val coverageDetails: String = ""
)
