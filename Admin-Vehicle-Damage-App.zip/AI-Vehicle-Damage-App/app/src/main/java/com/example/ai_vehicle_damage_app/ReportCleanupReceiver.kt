package com.example.ai_vehicle_damage_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReportCleanupReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReportCleanupService.startService(context)
    }
}