package com.example.ai_vehicle_damage_app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.firebase.database.*
import android.content.res.Resources

class UserListActivity : AppCompatActivity() {

    private lateinit var userListContainer: LinearLayout
    private val dbRef = FirebaseDatabase.getInstance().getReference("Users")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_list)

        userListContainer = findViewById(R.id.userListContainer)

        loadUsers()
    }

    private fun loadUsers() {
        dbRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                userListContainer.removeAllViews()

                if (!snapshot.exists()) {
                    val noUsersText = TextView(this@UserListActivity).apply {
                        text = "No users found"
                        setTextColor(android.graphics.Color.GRAY)
                        textSize = 18f
                    }
                    userListContainer.addView(noUsersText)
                    return
                }

                for (userSnapshot in snapshot.children) {
                    val nic = userSnapshot.key ?: continue
                    val userDetails = userSnapshot.child("UserDetails")
                    val vehicleDetails = userSnapshot.child("VehicleDetails")

                    val userName = userDetails.child("userName").getValue(String::class.java) ?: "N/A"
                    val vehicleNo = vehicleDetails.children.firstOrNull()?.key ?: "N/A"

                    val userButton = Button(this@UserListActivity).apply {
                        text = "$userName - $vehicleNo"
                        tag = nic
                        background = ContextCompat.getDrawable(context, R.drawable.banner_background)
                        setTextColor(ContextCompat.getColor(context, android.R.color.white))
                        setPadding(16.dpToPx(), 12.dpToPx(), 16.dpToPx(), 12.dpToPx())
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        ).apply {
                            setMargins(0, 0, 0, 8.dpToPx())
                        }
                        setOnClickListener {
                            val nicClicked = it.tag as String
                            openUserDetails(nicClicked)
                        }
                    }

                    userListContainer.addView(userButton)
                }
            }


            override fun onCancelled(error: DatabaseError) {
                showToast("Failed to load users: ${error.message}")
            }
        })
    }

    private fun openUserDetails(nic: String) {
        val intent = Intent(this, UserAllDetailsActivity::class.java)
        intent.putExtra("nic", nic)
        startActivity(intent)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }


    fun Int.dpToPx(): Int {
        return (this * Resources.getSystem().displayMetrics.density).toInt()
    }
}
