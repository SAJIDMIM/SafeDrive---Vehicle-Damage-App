package com.example.ai_vehicle_damage_app

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.text.SimpleDateFormat
import java.util.*

class ReportStatusActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    private lateinit var tvVehicleNo: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvDescription: TextView
    private lateinit var tvTimestamp: TextView
    private lateinit var statusCard: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report_status)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        initViews()

        val email = auth.currentUser?.email
        if (email != null) {
            findUserByEmail(email)
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }
    }

    private fun initViews() {
        tvVehicleNo = findViewById(R.id.tvVehicleNo)
        tvStatus = findViewById(R.id.tvStatus)
        tvDescription = findViewById(R.id.tvDescription)
        tvTimestamp = findViewById(R.id.tvTimestamp)
        statusCard = findViewById(R.id.statusCard)
        statusCard.visibility = View.GONE
    }

    private fun findUserByEmail(email: String) {
        database.child("Users").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (nicSnap in snapshot.children) {
                    val userEmail = nicSnap.child("UserDetails/email").value.toString()
                    if (userEmail == email) {
                        val nic = nicSnap.key.toString()
                        findVehicleAndLoadReport(nic)
                        return
                    }
                }
                Toast.makeText(this@ReportStatusActivity, "No matching user found", Toast.LENGTH_SHORT).show()
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun findVehicleAndLoadReport(userNic: String) {
        val vehicleDetailsRef = database.child("Users").child(userNic).child("VehicleDetails")
        vehicleDetailsRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (vehicleSnap in snapshot.children) {
                    val vehicleNo = vehicleSnap.key.toString()
                    loadReportStatus(vehicleNo)
                    return  // Load only one vehicle's report for now
                }
                Toast.makeText(this@ReportStatusActivity, "No vehicle found for your account", Toast.LENGTH_SHORT).show()
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun loadReportStatus(vehicleNo: String) {
        val reportRef = database.child("ReportStatus").child(vehicleNo)
        reportRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val status = snapshot.child("status").value.toString()
                    val description = snapshot.child("description").value.toString()
                    val timestamp = snapshot.child("timestamp").value.toString()

                    tvVehicleNo.text = "$vehicleNo"
                    tvStatus.text = "$status"
                    tvDescription.text = "$description"
                    tvTimestamp.text = "${formatTimestamp(timestamp)}"

                    statusCard.visibility = View.VISIBLE
                } else {
                    Toast.makeText(this@ReportStatusActivity, "No report found for this vehicle", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@ReportStatusActivity, "Failed to load report", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun formatTimestamp(timestampStr: String): String {
        return try {
            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
            val date = Date(timestampStr.toLong())
            sdf.format(date)
        } catch (e: Exception) {
            "-"
        }
    }
}
