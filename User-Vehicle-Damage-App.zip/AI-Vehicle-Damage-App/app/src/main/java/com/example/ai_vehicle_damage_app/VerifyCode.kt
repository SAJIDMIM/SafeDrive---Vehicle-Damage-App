package com.example.ai_vehicle_damage_app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class VerifyCode : AppCompatActivity() {

    private lateinit var codeEditText: EditText
    private lateinit var verifyButton: Button
    private lateinit var backButton: ImageView
    private lateinit var resendTextView: TextView
    private lateinit var email: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verify_code)

        codeEditText = findViewById(R.id.txt_code2)
        verifyButton = findViewById(R.id.btn_verifyCode)
        resendTextView = findViewById(R.id.textView9)

        // Get OTP and Email from intent
        val receivedOtp = intent.getStringExtra("otp_code")
        email = intent.getStringExtra("email") ?: ""

        codeEditText.setText(receivedOtp)

        // Hide verify button after 5 seconds
        Handler(Looper.getMainLooper()).postDelayed({
            verifyButton.visibility = Button.INVISIBLE
        }, 50000)

        // Back button goes to email input UI


        // Verify button click
        verifyButton.setOnClickListener {
            val enteredCode = codeEditText.text.toString()

            if (enteredCode == receivedOtp) {
                Toast.makeText(this, "Verification successful", Toast.LENGTH_SHORT).show()

                // Navigate to ForgotPassword UI after 1 second
                Handler(Looper.getMainLooper()).postDelayed({
                    val intent = Intent(this, ForgotPassword::class.java) // Change if class name differs
                    intent.putExtra("email", email) // Pass email if needed
                    startActivity(intent)
                    finish()
                }, 1000)

            } else {
                Toast.makeText(this, "Incorrect code. Please try again.", Toast.LENGTH_SHORT).show()
            }
        }

        // Uncomment and implement if you want resend functionality
        /*
        resendTextView.setOnClickListener {
            val newOtp = generateOTP()
            sendEmailWithSendGrid(email, newOtp)
            codeEditText.setText(newOtp)
            verifyButton.visibility = Button.VISIBLE

            Toast.makeText(this, "New code sent to $email", Toast.LENGTH_SHORT).show()

            Handler(Looper.getMainLooper()).postDelayed({
                verifyButton.visibility = Button.INVISIBLE
            }, 5000)
        }
        */
    }

    /*
    private fun generateOTP(): String {
        return Random.nextInt(10000, 99999).toString()
    }

    private fun sendEmailWithSendGrid(toEmail: String, otpCode: String) {
        // Implementation here
    }
    */
}
