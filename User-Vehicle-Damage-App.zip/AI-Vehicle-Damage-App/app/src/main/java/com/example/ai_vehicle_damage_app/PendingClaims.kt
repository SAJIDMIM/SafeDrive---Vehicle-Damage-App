package com.example.ai_vehicle_damage_app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class PendingClaims : AppCompatActivity() {

    // UI Components
    private lateinit var accidentReportsRecyclerView: RecyclerView

    // Firebase
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Firebase
        database = FirebaseDatabase.getInstance().reference

        // Check accident reports before showing layout
        checkAccidentReportsThenShowUI()
    }

    private fun checkAccidentReportsThenShowUI() {
        val accidentRef = database.child("AccidentReports")

        accidentRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(accidentSnapshot: DataSnapshot) {
                if (!accidentSnapshot.exists()) {
                    showToast("No accident reports found")
                    finish() // Close this screen
                    return
                }

                // Accident reports exist – proceed with layout
                setContentView(R.layout.activity_pending_cliams)  // Fixed the typo in the layout name
                supportActionBar?.setDisplayHomeAsUpEnabled(true)

                initializeViews()  // Initialize the views after setContentView

                // Wait for layout to be fully initialized, then load data
                loadAccidentReports(accidentSnapshot)
            }

            override fun onCancelled(error: DatabaseError) {
                showToast("Failed to load data: ${error.message}")
                Log.e("PendingClaims", "Failed to load accident data: ${error.message}")
                finish()
            }
        })
    }



    private fun initializeViews() {
        accidentReportsRecyclerView = findViewById(R.id.accidentReportsRecyclerView)
        accidentReportsRecyclerView.layoutManager = LinearLayoutManager(this)
    }

    private fun loadAccidentReports(accidentSnapshot: DataSnapshot) {
        val accidentVehicleNumbers = mutableListOf<String>()

        // Extract vehicle numbers from accident data
        for (accident in accidentSnapshot.children) {
            accident.child("vehicleNo").value?.toString()?.let {
                accidentVehicleNumbers.add(it)
            }
        }

        // Get user data from Firebase
        val userRef = database.child("Users")
        userRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(userSnapshot: DataSnapshot) {
                val validReports = mutableListOf<ClaimInfo>()

                // Collect valid reports by matching vehicle numbers
                userSnapshot.children.forEach { user ->
                    val userDetails = user.child("UserDetails")
                    val userName = userDetails.child("userName").value?.toString() ?: ""
                    val nic = userDetails.child("nic").value?.toString() ?: ""
                    val vehicleDetails = user.child("VehicleDetails")

                    accidentVehicleNumbers.forEach { vehicleNo ->
                        val vehicleInfo = vehicleDetails.child(vehicleNo).child("VehicleInfo")
                        if (vehicleInfo.exists()) {
                            val brand = vehicleInfo.child("brand").value?.toString() ?: ""
                            val model = vehicleInfo.child("model").value?.toString() ?: ""

                            // Log the values for debugging
                            Log.d("PendingClaims", "Vehicle No: $vehicleNo, Brand: $brand, Model: $model")

                            // Make sure all values are non-empty before adding to the list
                            if (userName.isNotEmpty() && nic.isNotEmpty() &&
                                brand.isNotEmpty() && model.isNotEmpty()) {
                                // Add to the list with the correct order
                                validReports.add(ClaimInfo(userName, nic, vehicleNo, brand, model))
                            }
                        }
                    }
                }

                // Display the reports in RecyclerView
                if (validReports.isNotEmpty()) {
                    val adapter = AccidentReportAdapter(validReports) { claimInfo ->
                        // When a report is clicked, navigate to the next UI
                        openReportDetails(claimInfo)
                    }
                    accidentReportsRecyclerView.adapter = adapter
                } else {
                    showToast("No matching user details found")
                    finish()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                showToast("Failed to load user data: ${error.message}")
                Log.e("PendingClaims", "Failed to load user data: ${error.message}")
                finish()
            }
        })
    }

    private fun openReportDetails(claimInfo: ClaimInfo) {
        // Open the report details screen
        val intent = Intent(this, ReportStatus::class.java).apply {
            putExtra("username", claimInfo.userName)
            putExtra("nic", claimInfo.nic)
            putExtra("brand", claimInfo.brand)
            putExtra("model", claimInfo.model)
            putExtra("vehicleNo", claimInfo.vehicleNo)
        }
        startActivity(intent)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                val intent = Intent(this, DamageReport::class.java)
                startActivity(intent)
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
