package com.example.ai_vehicle_damage_app

import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity

class AdminDashboard : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)




    }
}

