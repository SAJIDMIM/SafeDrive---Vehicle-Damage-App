package com.example.ai_vehicle_damage_app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.*

class NearestLocation : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mapView: MapView
    private lateinit var googleMap: GoogleMap
    private lateinit var searchButton: Button
    private lateinit var searchEditText: EditText
    private lateinit var refreshButton: ImageButton
    private val MAP_VIEW_BUNDLE_KEY = "MapViewBundleKey"

    private val apiKey = "AIzaSyDusdL7WWT9FIV80gB34Gy0_UScRa9piSs"
    private var currentLocation: LatLng? = null
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private val LOCATION_PERMISSION_REQUEST_CODE = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nearest_location)

        val mapViewBundle = savedInstanceState?.getBundle(MAP_VIEW_BUNDLE_KEY)
        mapView = findViewById(R.id.mapView)
        searchButton = findViewById(R.id.searchButton)
        searchEditText = findViewById(R.id.searchEditText)
        refreshButton = findViewById(R.id.refreshButton)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        mapView.onCreate(mapViewBundle)
        mapView.getMapAsync(this)

        refreshButton.setOnClickListener {
            getCurrentLocation()
        }

        searchButton.setOnClickListener {
            val searchText = searchEditText.text.toString().trim()
            if (searchText.isNotEmpty()) {
                fetchLocationFromAddressAndSearchServiceCenter(searchText)
            } else {
                Toast.makeText(this, "Enter address or name of the service center", Toast.LENGTH_SHORT).show()
            }

        }
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        MapsInitializer.initialize(applicationContext)

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE)
            return
        }

        googleMap.isMyLocationEnabled = true
        getCurrentLocation()

        googleMap.setOnMarkerClickListener { marker ->
            val lat = marker.position.latitude
            val lng = marker.position.longitude
            val uri = "http://maps.google.com/maps?q=loc:$lat,$lng(${marker.title})"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
            intent.setPackage("com.google.android.apps.maps")
            startActivity(intent)
            true
        }
    }

    private fun getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE)
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            location?.let {
                currentLocation = LatLng(it.latitude, it.longitude)
                googleMap.clear()
                updateMap(currentLocation!!, "You Are Here")
                searchNearbyVehicleServiceCenters(currentLocation!!)
            } ?: Toast.makeText(this, "Location not found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fetchLocationFromAddressAndSearchServiceCenter(searchText: String) {
        val geocoder = Geocoder(this, Locale.getDefault())
        try {
            val addresses: MutableList<Address>? = geocoder.getFromLocationName(searchText, 1)
            if (addresses!!.isNotEmpty()) {
                val address = addresses[0]
                val latLng = LatLng(address.latitude, address.longitude)
                Log.d("Geocoding Result", "Address: $searchText, LatLng: $latLng")

                googleMap.clear()
                updateMap(latLng, "Searched Location: $searchText")
                searchNearbyVehicleServiceCenters(latLng)
            } else {
                Toast.makeText(this, "Location not found for '$searchText'", Toast.LENGTH_SHORT).show()
            }
        } catch (e: IOException) {
            Toast.makeText(this, "Geocoding failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateMap(latLng: LatLng, title: String) {
        val iconColor = if (title == "You Are Here") {
            BitmapDescriptorFactory.HUE_RED // Red for current location
        } else {
            BitmapDescriptorFactory.HUE_GREEN // Green for other locations
        }

        googleMap.addMarker(
            MarkerOptions()
                .position(latLng)
                .title(title)
                .icon(BitmapDescriptorFactory.defaultMarker(iconColor))
        )
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 14f))
    }


    private fun searchNearbyVehicleServiceCenters(location: LatLng) {
        val radius = 10000
        val keywords = listOf("vehicle repair", "car garage", "auto mechanic", "auto repair shop")
        val encodedTitle = URLEncoder.encode(keywords.joinToString("|"), "UTF-8")
        val url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json" +
                "?location=${location.latitude},${location.longitude}" +
                "&radius=$radius&keyword=$encodedTitle&key=$apiKey"

        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(applicationContext, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                val responseBody = response.body?.string()
                Log.d("API Request", "URL: $url")
                Log.d("API Response", responseBody ?: "No Response Body")
                val json = JSONObject(responseBody ?: "")
                val results = json.optJSONArray("results") ?: return

                runOnUiThread {
                    if (results.length() == 0) {
                        Toast.makeText(applicationContext, "No service centers found", Toast.LENGTH_SHORT).show()
                    }

                    for (i in 0 until results.length()) {
                        val place = results.getJSONObject(i)
                        val name = place.optString("name")
                        val vicinity = place.optString("vicinity")
                        val lat = place.getJSONObject("geometry").getJSONObject("location").getDouble("lat")
                        val lng = place.getJSONObject("geometry").getJSONObject("location").getDouble("lng")

                        googleMap.addMarker(
                            MarkerOptions()
                                .position(LatLng(lat, lng))
                                .title("Service Center: $name")
                                .snippet(vicinity)
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                        )
                    }
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        var mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY)
        if (mapViewBundle == null) {
            mapViewBundle = Bundle()
            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle)
        }
        mapView.onSaveInstanceState(mapViewBundle)
        }
}
