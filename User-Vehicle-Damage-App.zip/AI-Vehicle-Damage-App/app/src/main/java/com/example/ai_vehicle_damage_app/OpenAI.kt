package com.example.ai_vehicle_damage_app

import androidx.appcompat.app.AppCompatActivity
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

class OpenAI : AppCompatActivity() {

    // OpenAI API request and response models
    data class Message(val role: String, val content: String)

    data class OpenAiRequest(
        val model: String = "gpt-3.5-turbo",
        val messages: List<Message>
    )

    data class OpenAiResponse(val choices: List<Choice>)
    data class Choice(val message: Message)

    // Retrofit interface for OpenAI API
    interface OpenAiService {
        @POST("v1/chat/completions")
        suspend fun getChatCompletion(
            @Body request: OpenAiRequest,
            @Header("Authorization") authHeader: String
        ): OpenAiResponse
    }

    // Retrofit client to create the OpenAiService instance
    object OpenAiClient {
        val service: OpenAiService by lazy {
            val retrofit = Retrofit.Builder()
                .baseUrl("https://api.openai.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            retrofit.create(OpenAiService::class.java)
        }
    }
}
