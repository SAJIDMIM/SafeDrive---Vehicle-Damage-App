package com.example.ai_vehicle_damage_app

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.util.Log
import android.view.MotionEvent
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.bumptech.glide.Glide

class AiChat : AppCompatActivity() {

    private lateinit var accidentRef: DatabaseReference
    private lateinit var chatMessages: MutableList<ChatMessage>
    private lateinit var recyclerView: RecyclerView
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var micImageView: ImageView
    private lateinit var cameraImageView: ImageView
    private lateinit var phoneImageView: ImageView
    private lateinit var editText: EditText

    private var imageUri: Uri? = null
    private val REQUEST_CODE_VOICE_INPUT = 1003
    private val REQUEST_CODE_RECORD_AUDIO = 101
    private val CAMERA_PERMISSION_CODE = 101
    private val CAMERA_REQUEST_CODE = 102

    private val predefinedPatterns = mapOf(
        "hello" to "Hello! How can I assist you today?",
        "damage cost" to "Please provide the vehicle ID to check the damage cost.",
        "vehicle id" to "Please provide your vehicle ID to retrieve the damage report.",
        "accident report" to "To fetch an accident report, please share the vehicle ID.",
        "help" to "I can help you with vehicle damage cost, accident reports, and more. How can I assist you?"
    )

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { isSuccess ->
            if (isSuccess) {
                imageUri?.let { uploadImageToFirebase(it) }
            } else {
                Toast.makeText(this, "Camera cancelled or failed", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ai_chat)

        accidentRef = FirebaseDatabase.getInstance().reference.child("AccidentReports")

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        chatMessages = mutableListOf()
        chatAdapter = ChatAdapter(chatMessages)
        recyclerView.adapter = chatAdapter

        editText = findViewById(R.id.editTextText14)
        micImageView = findViewById(R.id.imageView11)
        cameraImageView = findViewById(R.id.imageView12)
        phoneImageView = findViewById(R.id.imageView14)

        val backImageView = findViewById<ImageView>(R.id.backbtn)
        backImageView.setOnClickListener {
            val intent = Intent(this, UserDashboard::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }

        micImageView.setOnClickListener { checkAudioPermissionAndStartVoiceInput() }
        cameraImageView.setOnClickListener { checkCameraPermissionAndOpenCamera() }
        phoneImageView.setOnClickListener {
            val phoneNumber = "0726908294"
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
            startActivity(intent)
        }

        val sendButton = findViewById<ImageView>(R.id.imageView10)
        sendButton.setOnClickListener {
            val userMessage = editText.text.toString().trim()
            if (userMessage.isNotEmpty()) {
                addUserMessage(userMessage)
                handleUserMessage(userMessage)
                editText.text.clear()
            } else {
                Toast.makeText(this, "Please enter a message", Toast.LENGTH_SHORT).show()
            }
        }

        recyclerView.addOnItemTouchListener(object : RecyclerView.OnItemTouchListener {
            override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {}
            override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {}
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                val childView = rv.findChildViewUnder(e.x, e.y)
                if (childView != null) {
                    val position = rv.getChildAdapterPosition(childView)
                    showDeleteConfirmationDialog(position)
                }
                return false
            }
        })
    }

    private fun checkCameraPermissionAndOpenCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_CODE)

        } else {
            openCamera()
        }
    }

    private fun openCamera() {
        val contentValues = ContentValues().apply {
            put(MediaStore.Images.Media.TITLE, "New Image")
            put(MediaStore.Images.Media.DESCRIPTION, "From Camera")
        }
        imageUri =
            contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
        imageUri?.let { cameraLauncher.launch(it) }
    }

    private fun uploadImageToFirebase(uri: Uri) {
        val storageReference = FirebaseStorage.getInstance().reference
            .child("vehicle_images/${System.currentTimeMillis()}.jpg")

        val stream = contentResolver.openInputStream(uri)
        val byteArray = stream?.readBytes()

        if (byteArray != null) {
            storageReference.putBytes(byteArray)
                .addOnSuccessListener {
                    storageReference.downloadUrl.addOnSuccessListener { downloadUri ->
                        sendImageMessage(downloadUri.toString())
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to upload image", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun sendImageMessage(imageUrl: String) {
        val chatMessage = ChatMessage("user", "", imageUrl)  // Send image instead of text
        chatMessages.add(chatMessage)
        chatAdapter.notifyItemInserted(chatMessages.size - 1)
        recyclerView.scrollToPosition(chatMessages.size - 1)
    }

    private fun checkAudioPermissionAndStartVoiceInput() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_CODE_RECORD_AUDIO
            )
        } else {
            startVoiceInput()
        }
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say something...")
        }
        startActivityForResult(intent, REQUEST_CODE_VOICE_INPUT)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_VOICE_INPUT && resultCode == RESULT_OK) {
            val spokenText = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.get(0)
            spokenText?.let {
                addUserMessage(it)
                handleUserMessage(it)
            }
        } else if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            imageUri?.let { uploadImageToFirebase(it) }
        }
    }

    private fun addUserMessage(message: String) {
        chatMessages.add(ChatMessage("user", message))
        chatAdapter.notifyItemInserted(chatMessages.size - 1)
        recyclerView.scrollToPosition(chatMessages.size - 1)
    }

    private fun handleUserMessage(userMessage: String) {
        val pattern = Regex("\\b([A-Z]{2,3}-\\d{3,4})\\b", RegexOption.IGNORE_CASE)
        val match = pattern.find(userMessage)

        if (match != null) {
            val vehicleId = match.groupValues[1].uppercase()
            Log.d("DEBUG", "Extracted vehicleId: $vehicleId")
            fetchAccidentReport(vehicleId)
        } else {
            val autoResponse = getAutoResponse(userMessage)
            sendAdminMessage(autoResponse)
        }
    }

    private fun fetchAccidentReport(vehicleId: String) {
        accidentRef.child(vehicleId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var found = false
                for (reportSnapshot in snapshot.children) {
                    val reportVehicleNo =
                        reportSnapshot.child("vehicleNo").getValue(String::class.java)
                    Log.d("DEBUG", "Found vehicleNo in DB: $reportVehicleNo")

                    if (reportVehicleNo != null && reportVehicleNo.equals(
                            vehicleId,
                            ignoreCase = true
                        )
                    ) {
                        val location = reportSnapshot.child("location").getValue(String::class.java)
                        val estimateCost =
                            reportSnapshot.child("estimateCost").getValue(String::class.java)
                        val image1 = reportSnapshot.child("image1").getValue(String::class.java)

                        val response = buildString {
                            append("📍 Location: $location\n")
                            append("💸 Estimated Cost: Rs. $estimateCost\n")
                            if (!image1.isNullOrEmpty()) append("🖼️ Image: $image1")
                        }

                        sendAdminMessage(response)
                        found = true
                        break
                    }
                }

                if (!found) {
                    sendAdminMessage("❗ No accident report found for vehicle number $vehicleId.")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                sendAdminMessage("⚠️ Error retrieving data: ${error.message}")
            }
        })
    }

    private fun getAutoResponse(message: String): String {
        for ((keyword, response) in predefinedPatterns) {
            if (message.contains(keyword, ignoreCase = true)) {
                return response
            }
        }
        return "I'm sorry, I didn't understand that. Can you please clarify?"
    }

    private fun sendAdminMessage(message: String) {
        val adminMessage = ChatMessage("admin", message)
        chatMessages.add(adminMessage)
        chatAdapter.notifyItemInserted(chatMessages.size - 1)
        recyclerView.scrollToPosition(chatMessages.size - 1)
    }

    private fun showDeleteConfirmationDialog(position: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setMessage("Do you want to delete this message?")
            .setPositiveButton("Delete for me") { dialog, _ ->
                chatMessages.removeAt(position)
                chatAdapter.notifyItemRemoved(position)
                dialog.dismiss()
            }
            .setNegativeButton("Delete for everyone") { dialog, _ ->
                chatMessages.removeAt(position)
                chatAdapter.notifyItemRemoved(position)
                dialog.dismiss()
            }
            .setNeutralButton("Cancel") { dialog, _ -> dialog.dismiss() }
        builder.create().show()
    }
}
