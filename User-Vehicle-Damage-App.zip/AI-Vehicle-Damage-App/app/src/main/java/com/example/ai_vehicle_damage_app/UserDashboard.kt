package com.example.ai_vehicle_damage_app

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class UserDashboard : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_dashboard)

        // Get the username from the intent
        val username = intent.getStringExtra("username")

        // Find the TextView and set the welcome message
        val usernameTextView = findViewById<TextView>(R.id.txt_name)
        usernameTextView.text = "Welcome, $username!"

        // Find the ImageView for the vehicle report
        val vehicleImageView = findViewById<ImageView>(R.id.ic_accidentReport)

        // Set an onClickListener on the ImageView to open the Vehicle Report Activity
        vehicleImageView.setOnClickListener {
            val intent = Intent(this, DamageReport::class.java)
            intent.putExtra("username", username)  // Pass the username to the next activity
            startActivity(intent)
        }

        // Find the ImageView for Update Profile
        val updateProfileImageView = findViewById<ImageView>(R.id.ic_chatbot)

        // Set an onClickListener on the ImageView to open the Update Profile Activity
        updateProfileImageView.setOnClickListener {
            val intent = Intent(this, AiChat::class.java)
            intent.putExtra("username", username)
            startActivity(intent)
        }

        // Find the ImageView for User Policy
        val userPolicyImageView = findViewById<ImageView>(R.id.ic_userPolicy)

        // Set an onClickListener on the ImageView to open the PolicyHolderProfileActivity
        userPolicyImageView.setOnClickListener {
            val intent = Intent(this, PolicyHolderProfileActivity::class.java)
            intent.putExtra("username", username)
            startActivity(intent)
        }

        val nearestLocationImageView = findViewById<ImageView>(R.id.ic_nearestLocation)

// Set an onClickListener to open MapActivity
        nearestLocationImageView.setOnClickListener {
            val intent = Intent(this, NearestLocation::class.java)
            intent.putExtra("username", username)
            startActivity(intent)
        }


        val reportStatusImageView = findViewById<ImageView>(R.id.ic_ReportStatus)

// Set an onClickListener to open ReportStatusActivity
        reportStatusImageView.setOnClickListener {
            val intent = Intent(this, ReportStatusActivity::class.java)
            intent.putExtra("username", username)
            startActivity(intent)
        }
    }
}