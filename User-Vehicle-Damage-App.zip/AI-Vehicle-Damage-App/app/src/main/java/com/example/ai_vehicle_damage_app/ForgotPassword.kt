package com.example.ai_vehicle_damage_app

import android.content.Intent
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth

class ForgotPassword : AppCompatActivity() {

    private lateinit var edtCurrentPassword: EditText
    private lateinit var edtNewPassword: EditText
    private lateinit var edtConfirmPassword: EditText
    private lateinit var imgTogglePasswordVisibility: ImageView
    private lateinit var btnUpdatePassword: Button
    private lateinit var imgBackToLogin: ImageView

    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_password)

        // Initialize Firebase
        firebaseAuth = FirebaseAuth.getInstance()

        // Initialize views

        edtNewPassword = findViewById(R.id.txt_newpassword)
        edtConfirmPassword = findViewById(R.id.txt_re_newpassword)
        imgTogglePasswordVisibility = findViewById(R.id.passViewIcon)
        btnUpdatePassword = findViewById(R.id.btn_updatePassword)

        imgBackToLogin.setOnClickListener {
            startActivity(Intent(this, Login::class.java))
            finish()
        }

        // Toggle password visibility
        imgTogglePasswordVisibility.setOnClickListener {
            togglePasswordVisibility()
        }

        // Update password after re-authentication
        btnUpdatePassword.setOnClickListener {
            val currentPassword = edtCurrentPassword.text.toString().trim()
            val newPassword = edtNewPassword.text.toString().trim()
            val confirmPassword = edtConfirmPassword.text.toString().trim()

            if (currentPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
            } else if (newPassword != confirmPassword) {
                Toast.makeText(this, "New passwords do not match", Toast.LENGTH_SHORT).show()
            } else {
                reauthenticateAndChangePassword(currentPassword, newPassword)
            }
        }
    }

    private fun togglePasswordVisibility() {
        val isHidden = edtNewPassword.transformationMethod == PasswordTransformationMethod.getInstance()
        val method = if (isHidden) HideReturnsTransformationMethod.getInstance() else PasswordTransformationMethod.getInstance()
        val icon = if (isHidden) R.drawable.passview else R.drawable.hide

        edtCurrentPassword.transformationMethod = method
        edtNewPassword.transformationMethod = method
        edtConfirmPassword.transformationMethod = method
        imgTogglePasswordVisibility.setImageResource(icon)
    }

    private fun reauthenticateAndChangePassword(currentPassword: String, newPassword: String) {
        val user = firebaseAuth.currentUser

        if (user != null && user.email != null) {
            val credential = EmailAuthProvider.getCredential(user.email!!, currentPassword)

            user.reauthenticate(credential)
                .addOnSuccessListener {
                    user.updatePassword(newPassword)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                Toast.makeText(this, "Password updated successfully!", Toast.LENGTH_SHORT).show()
                                navigateToLoginScreen()
                            } else {
                                val errorMessage = task.exception?.message ?: "Password update failed"
                                Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
                            }
                        }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Re-authentication failed: ${it.message}", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToLoginScreen() {
        val intent = Intent(this, Login::class.java)
        startActivity(intent)
        finish()
    }
}
