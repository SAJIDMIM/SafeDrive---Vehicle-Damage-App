package com.example.ai_vehicle_damage_app

data class UserDetail(
    val name: String? = null,
    val nic: String? = null,
    val mobileNo: String? = null,
    val gender: String? = null,
    val dob: String? = null,
    val address: String? = null,
    val email: String? = null,
    val photoUrl: String? = null

)
