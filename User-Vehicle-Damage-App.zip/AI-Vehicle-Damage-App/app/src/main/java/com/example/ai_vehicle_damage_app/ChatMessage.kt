package com.example.ai_vehicle_damage_app

data class ChatMessage(
    val sender: String,
    val message: String = "",
    val imageUrl: String = ""
) {
    companion object {
        const val TEXT_TYPE = 1
        const val IMAGE_TYPE = 2
    }
}

