package com.example.ai_vehicle_damage_app

data class ReportStatus(
    val description: String = "",
    val reportId: String = "",
    val status: String = "",
    val timestamp: Long = 0,
    val vehicleNo: String = "",
    val userId: String = ""  // To connect with AppUsers
) {
    // Required empty constructor for Firebase
    constructor() : this("", "", "", 0, "", "")
}