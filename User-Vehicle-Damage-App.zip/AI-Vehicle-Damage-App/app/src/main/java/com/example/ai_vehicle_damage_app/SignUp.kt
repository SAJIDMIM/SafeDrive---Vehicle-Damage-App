package com.example.ai_vehicle_damage_app

import User
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.util.Patterns
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class SignUp : AppCompatActivity() {

    private lateinit var inputField: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var registerButton: Button
    private lateinit var loginRedirectText: TextView
    private lateinit var passViewIconPassword: ImageView
    private lateinit var passViewIconConfirmPassword: ImageView

    private lateinit var auth: FirebaseAuth
    private lateinit var databaseReference: DatabaseReference

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        auth = FirebaseAuth.getInstance()
        databaseReference = FirebaseDatabase.getInstance().getReference("Users")

        inputField = findViewById(R.id.txt_email)  // used for either username or email
        passwordEditText = findViewById(R.id.txt_password)
        confirmPasswordEditText = findViewById(R.id.txt_password2)
        registerButton = findViewById(R.id.btn_signup)
        loginRedirectText = findViewById(R.id.id_login)
        passViewIconPassword = findViewById(R.id.passViewIcon)
        passViewIconConfirmPassword = findViewById(R.id.passViewIcon2)

        registerButton.setOnClickListener { registerUser() }
        loginRedirectText.setOnClickListener {
            startActivity(Intent(this@SignUp, Login::class.java))
            finish()
        }

        passViewIconPassword.setOnClickListener {
            togglePasswordVisibility(passwordEditText, passViewIconPassword)
        }

        passViewIconConfirmPassword.setOnClickListener {
            togglePasswordVisibility(confirmPasswordEditText, passViewIconConfirmPassword)
        }
    }

    private fun togglePasswordVisibility(editText: EditText, imageView: ImageView) {
        if (editText.inputType == (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)) {
            editText.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            imageView.setImageResource(R.drawable.passview)
        } else {
            editText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            imageView.setImageResource(R.drawable.hide)
        }
        editText.setSelection(editText.text.length)
    }

    private fun registerUser() {
        val input = inputField.text.toString().trim()
        val password = passwordEditText.text.toString().trim()
        val confirmPassword = confirmPasswordEditText.text.toString().trim()

        val isEmail = Patterns.EMAIL_ADDRESS.matcher(input).matches()

        if (!isValidInput(input, password, confirmPassword, isEmail)) return

        registerButton.isEnabled = false

        if (!isEmail) {
            // Treat input as username and check uniqueness
            databaseReference.orderByChild("username").equalTo(input)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            showToast("Username already taken.")
                            inputField.error = "Username already in use!"
                            registerButton.isEnabled = true
                        } else {
                            // Use dummy email for username-based signup
                            val dummyEmail = "${input}@vehicleapp.com"
                            createFirebaseUser(input, dummyEmail, password)
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        showToast("Database error: ${error.message}")
                        registerButton.isEnabled = true
                    }
                })
        } else {
            // If it's an email, use the email as usual
            val username = input.substringBefore("@")
            createFirebaseUser(username, input, password)
        }
    }

    private fun createFirebaseUser(username: String, email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                registerButton.isEnabled = true
                if (task.isSuccessful) {
                    val userId = auth.currentUser?.uid ?: return@addOnCompleteListener
                    val user = User(username, email, password)
                    databaseReference.child(userId).setValue(user)
                    showToast("User registered successfully!")
                    clearInputFields()
                    startActivity(Intent(this, Login::class.java))
                    finish()
                } else {
                    showToast("Authentication failed: ${task.exception?.message}")
                }
            }
    }

    private fun isValidInput(input: String, password: String, confirmPassword: String, isEmail: Boolean): Boolean {
        if (TextUtils.isEmpty(input)) {
            inputField.error = "Username or email is required!"
            return false
        }

        if (!isEmail && input.contains(" ")) {
            inputField.error = "Username cannot contain spaces!"
            return false
        }

        if (isEmail && !Patterns.EMAIL_ADDRESS.matcher(input).matches()) {
            inputField.error = "Enter a valid email!"
            return false
        }

        if (TextUtils.isEmpty(password)) {
            passwordEditText.error = "Password is required!"
            return false
        }

        if (password.length < 6) {
            passwordEditText.error = "Password must be at least 6 characters!"
            return false
        }

        if (password != confirmPassword) {
            confirmPasswordEditText.error = "Passwords do not match!"
            return false
        }

        return true
    }

    private fun clearInputFields() {
        inputField.setText("")
        passwordEditText.setText("")
        confirmPasswordEditText.setText("")
    }

    private fun showToast(message: String) {
        Toast.makeText(this@SignUp, message, Toast.LENGTH_SHORT).show()
    }
}
