package com.example.ai_vehicle_damage_app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AccidentReportAdapter(
    private val reportList: List<ClaimInfo>,
    private val onItemClick: (ClaimInfo) -> Unit
) : RecyclerView.Adapter<AccidentReportAdapter.ReportViewHolder>() {

    inner class ReportViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtUserName: TextView = view.findViewById(R.id.txt_user_name)
        val txtNIC: TextView = view.findViewById(R.id.txt_nic)
        val txtVehicleNo: TextView = view.findViewById(R.id.txt_vehicle_no)
        val txtVehicleBrand: TextView = view.findViewById(R.id.txt_vehicle_brand)
        val txtVehicleModel: TextView = view.findViewById(R.id.txt_vehicle_model)

        fun bind(claimInfo: ClaimInfo) {
            txtUserName.text = "Name: ${claimInfo.userName}"
            txtNIC.text = "NIC: ${claimInfo.nic}"
            txtVehicleNo.text = "Vehicle No: ${claimInfo.vehicleNo}" // Correct binding for vehicle number
            txtVehicleBrand.text = "Brand: ${claimInfo.brand}" // Correct binding for brand
            txtVehicleModel.text = "Model: ${claimInfo.model}" // Correct binding for model

            itemView.setOnClickListener {
                onItemClick(claimInfo)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReportViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.vehicle_accident_report, parent, false)
        return ReportViewHolder(view)
    }

    override fun onBindViewHolder(holder: ReportViewHolder, position: Int) {
        holder.bind(reportList[position])
    }

    override fun getItemCount(): Int = reportList.size
}
