package com.example.ai_vehicle_damage_app

import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.text.SimpleDateFormat
import java.util.*

class DamageReport : AppCompatActivity() {

    private lateinit var txtVehicleNo: EditText
    private lateinit var txtDate: EditText
    private lateinit var txtLocation: EditText
    private lateinit var txtReasonDamage: EditText
    private lateinit var txtCompany: EditText
    private lateinit var txtEstimateCost: EditText
    private lateinit var btnReport: Button

    private lateinit var photo1: ImageView
    private lateinit var photo2: ImageView
    private lateinit var photo3: ImageView

    private var imageUris = arrayOfNulls<Uri>(3)
    private var currentImageIndex = 0

    private val storage = FirebaseStorage.getInstance()
    private val database = FirebaseDatabase.getInstance()
    private val vehicleRegistry = database.getReference("RegisteredVehicles")
    private val reportRef = database.getReference("AccidentReports")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_damage_report)

        txtVehicleNo = findViewById(R.id.txt_VehicleNo)
        txtDate = findViewById(R.id.txt_damageDate)
        txtLocation = findViewById(R.id.txt_location)
        txtReasonDamage = findViewById(R.id.txt_reason)

        txtCompany = findViewById(R.id.text_estimateCompany)
        txtEstimateCost = findViewById(R.id.txt_estimateCost)
        btnReport = findViewById(R.id.btn_Report)

        photo1 = findViewById(R.id.ic_photo1)
        photo2 = findViewById(R.id.ic_photo2)
        photo3 = findViewById(R.id.ic_photo3)

        txtDate.setOnClickListener { showDatePicker() }

        photo1.setOnClickListener { selectImage(0) }
        photo2.setOnClickListener { selectImage(1) }
        photo3.setOnClickListener { selectImage(2) }

        btnReport.setOnClickListener { validateAndSubmit() }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(this, { _, y, m, d ->
            val dateStr = "${d.toString().padStart(2, '0')}/${(m + 1).toString().padStart(2, '0')}/$y"
            txtDate.setText(dateStr)
        }, year, month, day).show()
    }

    private fun selectImage(index: Int) {
        currentImageIndex = index
        imagePicker.launch(arrayOf("image/*"))
    }

    private val imagePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            imageUris[currentImageIndex] = it
            when (currentImageIndex) {
                0 -> photo1.setImageURI(it)
                1 -> photo2.setImageURI(it)
                2 -> photo3.setImageURI(it)
            }
        }
    }

    private fun validateAndSubmit() {
        val vehicleNo = txtVehicleNo.text.toString().trim()
        val date = txtDate.text.toString().trim()
        val location = txtLocation.text.toString().trim()
        val reasonDamage = txtReasonDamage.text.toString().trim()

        val company = txtCompany.text.toString().trim()
        val cost = txtEstimateCost.text.toString().trim()

        if (vehicleNo.isEmpty() || date.isEmpty() || location.isEmpty() || reasonDamage.isEmpty() ||
            company.isEmpty() || cost.isEmpty() || imageUris.any { it == null }) {
            Toast.makeText(this, "Please fill all fields and select all images", Toast.LENGTH_SHORT).show()
            return
        }

        // Step 1: Check if vehicle is registered
        vehicleRegistry.child(vehicleNo).get().addOnSuccessListener { snapshot ->
            if (!snapshot.exists()) {
                Toast.makeText(this, "Vehicle not registered by admin", Toast.LENGTH_LONG).show()
                return@addOnSuccessListener
            }

            // Step 2: Check for duplicate report on the same date
            reportRef.child(vehicleNo).get().addOnSuccessListener { reportsSnapshot ->
                val duplicateExists = reportsSnapshot.children.any { report ->
                    val reportDate = report.child("date").getValue(String::class.java)
                    reportDate == date
                }

                if (duplicateExists) {
                    Toast.makeText(this, "Report for this date already exists", Toast.LENGTH_LONG).show()
                } else {
                    val reportId = generateTimestampId()
                    uploadImagesAndSaveReport(vehicleNo, reportId, date, location, reasonDamage , company, cost)
                }
            }.addOnFailureListener {
                Toast.makeText(this, "Failed to check existing reports", Toast.LENGTH_SHORT).show()
            }
        }.addOnFailureListener {
            Toast.makeText(this, "Error checking vehicle registration", Toast.LENGTH_SHORT).show()
        }
    }


    private fun generateTimestampId(): String {
        val sdf = SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault())
        return sdf.format(Date())
    }

    private fun uploadImagesAndSaveReport(
        vehicleNo: String,
        reportId: String,
        date: String,
        location: String,
        reasonDamage: String,
        company: String,
        cost: String
    ) {
        val imageUrls = mutableListOf<String>()

        imageUris.forEachIndexed { index, uri ->
            val ref = storage.reference.child("damage_reports/$vehicleNo/$reportId/image$index.jpg")
            ref.putFile(uri!!)
                .continueWithTask { task ->
                    if (!task.isSuccessful) throw task.exception ?: Exception("Upload failed")
                    ref.downloadUrl
                }
                .addOnSuccessListener { url ->
                    imageUrls.add(url.toString())
                    if (imageUrls.size == 3) {
                        saveReportToRealtimeDB(vehicleNo, reportId, date, location, reasonDamage, company, cost, imageUrls)
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Image upload failed", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun saveReportToRealtimeDB(
        vehicleNo: String,
        reportId: String,
        date: String,
        location: String,
        reasonDamage: String,
        company: String,
        cost: String,
        imageUrls: List<String>
    ) {
        val report = mapOf(
            "vehicleNo" to vehicleNo,
            "date" to date,
            "location" to location,
            "reasonDamage" to reasonDamage,
            "estimateCompany" to company,
            "estimateCost" to cost,
            "image1" to imageUrls[0],
            "image2" to imageUrls[1],
            "image3" to imageUrls[2],
            "timestamp" to System.currentTimeMillis()
        )

        reportRef.child(vehicleNo).child(reportId).setValue(report)
            .addOnSuccessListener {
                Toast.makeText(this, "Report submitted successfully", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to submit report", Toast.LENGTH_SHORT).show()
                } }
}
