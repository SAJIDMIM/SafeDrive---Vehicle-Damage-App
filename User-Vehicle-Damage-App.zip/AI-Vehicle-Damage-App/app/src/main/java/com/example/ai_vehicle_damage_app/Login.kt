package com.example.ai_vehicle_damage_app

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.util.Patterns
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.auth.GoogleAuthProvider
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.android.gms.auth.api.signin.GoogleSignInOptions

class Login : AppCompatActivity() {

    private lateinit var loginInput: EditText
    private lateinit var loginPassword: EditText
    private lateinit var loginButton: Button
    private lateinit var signupRedirectText: TextView
    private lateinit var passViewIcon: ImageView
    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference
    private lateinit var googleSignInClient: GoogleSignInClient
    private val RC_SIGN_IN = 9001

    private val adminUsername = "admin@safedriveteam.com"
    private val adminPassword = "adminsafedrive123"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        loginInput = findViewById(R.id.txt_email)
        loginPassword = findViewById(R.id.txt_password)
        loginButton = findViewById(R.id.btn_login)
        signupRedirectText = findViewById(R.id.id_signup)
        passViewIcon = findViewById(R.id.passViewIcon)

        val forgotPasswordText: TextView = findViewById(R.id.textView2)
        val googleSignInImageView: ImageView = findViewById(R.id.imageView2)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().getReference("Users")

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

        passViewIcon.setOnClickListener {
            if (loginPassword.inputType == (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)) {
                loginPassword.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                passViewIcon.setImageResource(R.drawable.passview)
            } else {
                loginPassword.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                passViewIcon.setImageResource(R.drawable.hide)
            }
            loginPassword.setSelection(loginPassword.text.length)
        }

        loginButton.setOnClickListener {
            val input = loginInput.text.toString().trim()
            val password = loginPassword.text.toString().trim()

            if (input.isEmpty()) {
                loginInput.error = "Enter username or email"
                return@setOnClickListener
            }

            if (password.length < 6) {
                loginPassword.error = "Password must be at least 6 characters"
                return@setOnClickListener
            }

            if (input == adminUsername && password == adminPassword) {
                Toast.makeText(this, "Admin Login Successful", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, AdminDashboard::class.java))
                finish()
                return@setOnClickListener
            }

            if (Patterns.EMAIL_ADDRESS.matcher(input).matches()) {
                loginWithEmail(input, password)
            } else {
                findEmailByUsername(input) { email ->
                    if (email != null) {
                        loginWithEmail(email, password)
                    } else {
                        Toast.makeText(this, "Username not found", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        signupRedirectText.setOnClickListener {
            startActivity(Intent(this, SignUp::class.java))
        }

        forgotPasswordText.setOnClickListener {
            startActivity(Intent(this, Verification::class.java))
        }

        googleSignInImageView.setOnClickListener {
            signInWithGoogle()
        }
    }

    private fun loginWithEmail(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                goToUserDashboard()
            }
            .addOnFailureListener { e ->
                Log.e("LoginError", "Login failed: ${e.message}")
                Toast.makeText(this, "Login Failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun findEmailByUsername(username: String, callback: (String?) -> Unit) {
        database.orderByChild("username").equalTo(username)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        for (userSnapshot in snapshot.children) {
                            val email = userSnapshot.child("email").getValue(String::class.java)
                            callback(email)
                            return
                        }
                    } else {
                        callback(null)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    callback(null)
                }
            })
    }

    private fun signInWithGoogle() {
        val signInIntent: Intent = googleSignInClient.signInIntent
        signInIntent.putExtra("forceSignIn", true) // Forces the account chooser to appear
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == RC_SIGN_IN) {
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = task.getResult(ApiException::class.java)
                firebaseAuthWithGoogle(account)
            } catch (e: ApiException) {
                Log.w("Google SignIn", "Google sign in failed", e)
                Toast.makeText(this, "Google Sign-In Failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun firebaseAuthWithGoogle(account: GoogleSignInAccount?) {
        val email = account?.email ?: ""
        val credential = GoogleAuthProvider.getCredential(account?.idToken, null)

        if (email == adminUsername) {
            val passwordInput = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }

            AlertDialog.Builder(this)
                .setTitle("Enter Admin Password")
                .setMessage("This admin account requires a password.")
                .setView(passwordInput)
                .setPositiveButton("Submit") { _, _ ->
                    val enteredPassword = passwordInput.text.toString()
                    if (enteredPassword == adminPassword) {
                        auth.signInWithCredential(credential)
                            .addOnCompleteListener(this) { task ->
                                if (task.isSuccessful) {
                                    startActivity(Intent(this, AdminDashboard::class.java))
                                    finish()
                                } else {
                                    Toast.makeText(this, "Authentication Failed.", Toast.LENGTH_SHORT).show()
                                }
                            }
                    } else {
                        Toast.makeText(this, "Incorrect Password.", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel") { dialog, _ ->
                    dialog.dismiss()
                }
                .setCancelable(false)
                .show()
        } else {
            auth.signInWithCredential(credential)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        showSignOutDialog()
                    } else {
                        Toast.makeText(this, "Authentication Failed.", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }

    private fun showSignOutDialog() {
        AlertDialog.Builder(this)
            .setTitle("Google Account")
            .setMessage("Do you want to sign out?")
            .setPositiveButton("Sign Out") { _, _ ->
                googleSignInClient.signOut().addOnCompleteListener {
                    Toast.makeText(this, "Signed out from Google account", Toast.LENGTH_SHORT).show()
                    signInWithGoogle() // Prompt user to sign in again
                }
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .setNeutralButton("Continue") { _, _ ->
                goToUserDashboard()
            }
            .setCancelable(false)
            .show()
    }

    private fun goToUserDashboard() {
        val userId = auth.currentUser?.uid ?: return
        database.child(userId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val username = snapshot.child("username").getValue(String::class.java)
                val intent = Intent(this@Login, UserDashboard::class.java)
                intent.putExtra("username", username ?: "User")
                startActivity(intent)
                finish()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@Login, "Failed to retrieve user data", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
