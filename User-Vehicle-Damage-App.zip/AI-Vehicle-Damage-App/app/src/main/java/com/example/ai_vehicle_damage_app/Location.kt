package com.example.ai_vehicle_damage_app

data class Location(
    var id: Int = 0,
    var name: String = ""
) {
    override fun toString(): String {
        return name
    }
}
