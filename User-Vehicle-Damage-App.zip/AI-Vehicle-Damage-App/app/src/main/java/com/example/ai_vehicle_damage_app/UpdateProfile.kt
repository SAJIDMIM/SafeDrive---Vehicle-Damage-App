package com.example.ai_vehicle_damage_app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage

class UpdateProfile : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var nicEditText: EditText
    private lateinit var mobileEditText: EditText
    private lateinit var genderGroup: RadioGroup
    private lateinit var maleRadio: RadioButton
    private lateinit var femaleRadio: RadioButton
    private lateinit var usernameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var dobEditText: EditText
    private lateinit var addressEditText: EditText
    private lateinit var profileImageView: ImageView
    private lateinit var saveButton: Button
    private lateinit var reloadButton: Button

    private var selectedImageUri: Uri? = null

    private lateinit var auth: FirebaseAuth
    private lateinit var dbRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_profile)

        // Initialize views
        nameEditText = findViewById(R.id.et_name)
        nicEditText = findViewById(R.id.et_nic)
        mobileEditText = findViewById(R.id.et_mobile)
        genderGroup = findViewById(R.id.gender_group)
        maleRadio = findViewById(R.id.radio_male)
        femaleRadio = findViewById(R.id.radio_female)
        usernameEditText = findViewById(R.id.et_username)
        emailEditText = findViewById(R.id.et_email)
        dobEditText = findViewById(R.id.et_dob)
        addressEditText = findViewById(R.id.et_address)
        profileImageView = findViewById(R.id.imageView8)
        saveButton = findViewById(R.id.btn_update)
        reloadButton = findViewById(R.id.btn_reload)

        auth = FirebaseAuth.getInstance()
        dbRef = FirebaseDatabase.getInstance().reference

        val userId = auth.currentUser?.uid
        if (userId != null) {
            dbRef.child("Users").child(userId).child("username")
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val username = snapshot.getValue(String::class.java)
                        usernameEditText.setText(username)
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Toast.makeText(this@UpdateProfile, "Failed to load username", Toast.LENGTH_SHORT).show()
                    }
                })

            auth.currentUser?.email?.let {
                emailEditText.setText(it)
            }
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        nicEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_NEXT || actionId == EditorInfo.IME_ACTION_GO) {
                val enteredNIC = nicEditText.text.toString().trim()
                if (enteredNIC.isNotEmpty()) {
                    val nic = enteredNIC.toIntOrNull()  // Convert NIC to integer safely
                    if (nic != null) {
                        fetchDetailsByNIC(nic)
                    } else {
                        Toast.makeText(this, "Invalid NIC", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Please enter NIC", Toast.LENGTH_SHORT).show()
                }
                true
            } else {
                false
            }
        }

        reloadButton.setOnClickListener {
            val enteredNIC = nicEditText.text.toString().trim()
            if (enteredNIC.isNotEmpty()) {
                val nic = enteredNIC.toIntOrNull()  // Convert NIC to integer safely
                if (nic != null) {
                    fetchDetailsByNIC(nic)
                } else {
                    Toast.makeText(this, "Invalid NIC", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter NIC", Toast.LENGTH_SHORT).show()
            }
        }

        profileImageView.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            imagePickerLauncher.launch(intent)
        }

        saveButton.setOnClickListener {
            val nicString = nicEditText.text.toString().trim()
            val nic = nicString.toIntOrNull()  // Convert NIC to integer safely
            val name = nameEditText.text.toString().trim()
            val mobile = mobileEditText.text.toString().trim()
            val gender = if (maleRadio.isChecked) "Male" else "Female"
            val dob = dobEditText.text.toString().trim()
            val address = addressEditText.text.toString().trim()
            val email = emailEditText.text.toString().trim()

            if (nic == null || name.isEmpty()) {
                Toast.makeText(this, "NIC and Name are required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (selectedImageUri != null) {
                uploadImageAndSaveData(nic, name, mobile, gender, dob, address, email, selectedImageUri!!)
            } else {
                saveUserData(nic, name, mobile, gender, dob, address, email, null)
            }
        }
    }

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            selectedImageUri = result.data!!.data
            profileImageView.setImageURI(selectedImageUri)
        }
    }

    private fun fetchDetailsByNIC(nic: Int) {
        Log.d("UpdateProfile", "Searching for NIC: $nic")
        dbRef.child("UserDetails").child(nic.toString())  // Query by integer NIC
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val userDetails = snapshot.getValue(UserDetail::class.java)
                        if (userDetails != null) {
                            nameEditText.setText(userDetails.name)
                            mobileEditText.setText(userDetails.mobileNo)
                            dobEditText.setText(userDetails.dob)
                            addressEditText.setText(userDetails.address)

                            when (userDetails.gender) {
                                "Male" -> maleRadio.isChecked = true
                                "Female" -> femaleRadio.isChecked = true
                            }

                            if (!userDetails.photoUrl.isNullOrEmpty()) {
                                Glide.with(this@UpdateProfile)
                                    .load(userDetails.photoUrl)
                                    .into(profileImageView)
                            }
                        }
                    } else {
                        Toast.makeText(this@UpdateProfile, "NIC not found", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@UpdateProfile, "Failed to fetch data", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun uploadImageAndSaveData(
        nic: Int, name: String, mobile: String, gender: String,
        dob: String, address: String, email: String, imageUri: Uri
    ) {
        val storageRef = FirebaseStorage.getInstance().reference
            .child("profile_images/$nic.jpg")

        storageRef.putFile(imageUri)
            .addOnSuccessListener {
                storageRef.downloadUrl.addOnSuccessListener { uri ->
                    val imageUrl = uri.toString()
                    saveUserData(nic, name, mobile, gender, dob, address, email, imageUrl)
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Image upload failed", Toast.LENGTH_SHORT).show()
            }
    }

    private fun saveUserData(
        nic: Int, name: String, mobile: String, gender: String,
        dob: String, address: String, email: String, imageUrl: String?
    ) {
        val userMap = HashMap<String, Any>()
        userMap["name"] = name
        userMap["nic"] = nic
        userMap["mobileNo"] = mobile
        userMap["gender"] = gender
        userMap["dob"] = dob
        userMap["address"] = address
        userMap["email"] = email
        if (imageUrl != null) {
            userMap["photoUrl"] = imageUrl
        }

        dbRef.child("UserDetails").child(nic.toString()).setValue(userMap)
            .addOnSuccessListener {
                Toast.makeText(this, "Profile updated successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to update profile", Toast.LENGTH_SHORT).show()
            }
    }
}
