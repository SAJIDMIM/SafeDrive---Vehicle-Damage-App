package com.example.ai_vehicle_damage_app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Properties
import javax.mail.*
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage
import java.util.Random

class Verification : AppCompatActivity() {

    private lateinit var txtEmailSent: TextView
    private lateinit var emailEditText: EditText
    private lateinit var sendButton: Button

    private var verificationCode: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verification)

        txtEmailSent = findViewById(R.id.txt_email)
        sendButton = findViewById(R.id.btn_send)
        emailEditText = findViewById(R.id.txt_email)

//        val backButton = findViewById<ImageView>(R.id.btn_back)
//        backButton.setOnClickListener {
//            val intent = Intent(this, Login::class.java)
//            startActivity(intent)
//            finish()
//        }

        sendButton.setOnClickListener {
            val userEmail = emailEditText.text.toString().trim()

            if (userEmail.isNotEmpty() && Patterns.EMAIL_ADDRESS.matcher(userEmail).matches()) {
                startVerificationProcess(userEmail)
            } else {
                txtEmailSent.text = "Please enter a valid email address."
                Log.d("Verification", "Invalid email entered.")
            }
        }
    }

    private fun generateRandomCode(): String {
        val random = Random()
        return String.format("%05d", random.nextInt(100000))
    }

    private fun sendVerificationEmail(code: String, recipientEmail: String) {
        Log.d("Verification", "Sending verification email to $recipientEmail with code: $code")

        runOnUiThread {
            txtEmailSent.text = "Sending email to $recipientEmail..."
        }

        Thread {
            val properties = Properties().apply {
                put("mail.smtp.auth", "true")
                put("mail.smtp.starttls.enable", "true")
                put("mail.smtp.host", "smtp.gmail.com")
                put("mail.smtp.port", "587")
            }

            val session = Session.getInstance(properties, object : Authenticator() {
                override fun getPasswordAuthentication(): PasswordAuthentication {
                    return PasswordAuthentication("mohamedsajid450@gmail.com", "rytvucuwdxuuoskn")
                }
            })

            try {
                val messageContent = """
                    Hello,

                    Here is your verification code to reset your password:

                    Code: $code

                    The code will expire in 1 minute. Please use it before it expires.

                    If you did not request a password reset, please ignore this email.

                    Regards,
                    SafeDrive Team
                """.trimIndent()

                val message = MimeMessage(session).apply {
                    setFrom(InternetAddress("mohamedsajid450@gmail.com"))
                    addRecipient(Message.RecipientType.TO, InternetAddress(recipientEmail))
                    subject = "Password Reset SafeDrive"
                    setText(messageContent)
                }

                Transport.send(message)

                runOnUiThread {
                    txtEmailSent.text = "Verification email sent to $recipientEmail"
                    Toast.makeText(applicationContext, "Email sent!", Toast.LENGTH_SHORT).show()

                    val intent = Intent(this@Verification, VerifyCode::class.java)
                    intent.putExtra("otp_code", code)
                    startActivity(intent)
                }

            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("EmailError", "Failed to send email: ${e.message}")
                runOnUiThread {
                    txtEmailSent.text = "Failed to send email. Please try again."
                }
            }
        }.start()
    }

    private fun startVerificationProcess(recipientEmail: String) {
        verificationCode = generateRandomCode()
        sendVerificationEmail(verificationCode, recipientEmail)
    }
}
