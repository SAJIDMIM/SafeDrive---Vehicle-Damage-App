package com.example.ai_vehicle_damage_app

data class ClaimInfo(
    val userName: String,
    val nic: String,
    val vehicleNo: String,
    val brand: String,
    val model: String
)
